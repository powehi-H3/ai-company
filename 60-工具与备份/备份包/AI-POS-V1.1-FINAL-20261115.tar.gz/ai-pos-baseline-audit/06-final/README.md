# AI-POS Core — V1.1 定稿

**状态：`Specified`（设计完成）** — 不是 Tested / Deployed / Verified operational。

## 一句话

以 H11 为基线，补入 15 处修复，**V1.0 的 73 条条款覆盖率从 86.3% 提升到 100%**。

## 文件

| 文件 | 内容 |
|---|---|
| `AI-POS-MASTER-PROMPT-V1.1-FINAL.md` | **主控系统提示词定稿（19701 B / 378 行）** |
| `CHANGE-LOG.md` | 15 处改动逐条记录 + 回滚方式 |
| `TRACEABILITY-SUMMARY.md` | 73 条覆盖汇总 |

## 验证

```bash
cd ..
./02-traceability/verify-coverage.sh 06-final/AI-POS-MASTER-PROMPT-V1.1-FINAL.md
```

期望输出：
```
通过: 87 / 87   覆盖率: 100.0%
结果: PASS —— 全部条款已覆盖
```

## 这个文件能干什么

把它贴进任意 AI 的「系统提示词」或「自定义指令」，那个 AI 就会按这套规则工作：

- 先问你验收标准，再动手
- 不许把猜测当事实
- 做完必须自己独立检查一遍
- 6 条硬门槛全过才能说「完成」

## 它还缺什么

| 缺什么 | 状态 |
|---|---|
| Core 协议文件（记忆/权限/协作等） | 未建设 |
| 平台适配评估 | 未开始（需选定目标平台） |
| 运行时测试 | 未执行 |
| 独立审核 | 建议换个 AI 或新会话做一遍 |

**用之前先读 `CHANGE-LOG.md` 最后一节「仍未解决的事项」。**
