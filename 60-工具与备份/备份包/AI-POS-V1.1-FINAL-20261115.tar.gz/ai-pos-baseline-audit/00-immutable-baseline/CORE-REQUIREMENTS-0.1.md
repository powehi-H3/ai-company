# AI-POS Core Requirements

## Product objective

A platform-independent personal AI work operating system that helps one user move complex work from intent to verified delivery, while supporting both a single primary agent and optional multi-agent collaboration.

## Confirmed decisions

- Platform-independent core.
- Primary-agent-first operating model.
- Multi-agent capability as an optional extension.
- Core first; advanced autonomy later.
- User controls goals, authorization, and material decisions.
- AI owns professional analysis, execution within permissions, verification, and closure.

## Functional requirements

### FR-01 Intent and requirements
- Extract desired outcome, explicit constraints, deliverables, deadline if supplied, and acceptance criteria.
- Distinguish known facts, assumptions, unknowns, and contradictions.
- Classify requirements as Must / Should / Could / Won't.
- Ask only for decisions that materially affect correctness, risk, or scope.

### FR-02 Planning
- Decompose complex work into tasks with input, output, dependencies, owner/role, risk, and completion test.
- Identify critical path and blockers.
- Avoid creating process overhead for simple tasks.

### FR-03 Research
- Use appropriate current sources when freshness matters.
- Prefer primary/official evidence where available.
- Link material claims to sources or artifacts.
- Record conflicting evidence and uncertainty.

### FR-04 Execution
- Discover available tools and capabilities before assuming access.
- Use tools only within granted permissions.
- Preserve originals and create recoverable changes.
- Record actions and results.

### FR-05 Collaboration
- Support logical roles even if only one model instance is available.
- Delegate to separate agents only when supported and beneficial.
- Require structured handoffs and explicit synthesis.

### FR-06 Review and verification
- Compare deliverables against original requirements.
- Use tests, source checks, file inspection, or other observable evidence.
- Separate self-review from independent review where possible.
- Report unresolved defects honestly.

### FR-07 Project continuity
- Maintain canonical project state, decisions, task status, artifacts, and test evidence.
- Recover from files/records before relying on conversational recollection.
- Provide a compact handover snapshot for new sessions.

### FR-08 Safety and permissions
- Separate read-only, reversible write, execution, external communication, financial/legal/high-impact, and irreversible actions.
- Require explicit authorization for actions beyond granted scope.
- Stop and escalate on ambiguous high-risk actions.

### FR-09 Completion
- A task is complete only when deliverables exist and acceptance checks pass.
- Distinguish designed, implemented, tested, accepted, and deployed.

## Non-functional requirements

- Portable Markdown-first documentation.
- Human-readable and editable.
- Minimal mandatory dependencies.
- Traceable decisions and changes.
- Recoverable state.
- Modular rules with one canonical source per rule.
- No hidden dependency on a specific model vendor.
- Usable without multi-agent runtime.
- Progressive complexity: Core before Advanced.

## Out of scope for Core 1.0

- Autonomous self-modification of core policies.
- Always-on autonomous agents.
- Unattended high-impact external actions.
- Mandatory vector database, graph database, or orchestration framework.
- Vendor-specific SDK as a core dependency.
