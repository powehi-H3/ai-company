# 01 — 输入清单与完整性核对

生成时间：2026-11-15（Asia/Shanghai）
核对方式：对四个 ZIP 逐文件计算 SHA-256，并对同内容文件做跨包去重比对。

## 1.1 收到的输入（4 个 ZIP）

| # | 包名 | 声明大小 | 声明 SHA-256（前12位） | 解压文件数 |
|---|---|---|---|---|
| 1 | AI-POS-Core-Architecture-Pack-0.1.zip | 16966 B | 3a9ed14e6fce | 12 |
| 2 | AI-POS-Core-V1.1-Handoff-Pack.zip | 9422 B | ade18f59c821 | 3 |
| 3 | AI-POS-Core-Combined-Review-Pack-0.2.zip | 30471 B | 819901ab6581 | 28（含 3 个空目录） |
| 4 | AI-POS-Core-Unified-Delivery-0.3.zip | 18250 B | cd5505c49dd2 | 17 |

## 1.2 逐文件清单（48 个文件，含跨包重复副本）

| 包 | 相对路径 | 字节 | SHA-256 |
|---|---|---|---|
| A01 | `README.md` | 1881 | `67ed4d0745aecc0d0355353d875013fdaea7a74dae16d98074749c61e387170a` |
| A01 | `02-architecture/CORE-ARCHITECTURE.md` | 2845 | `8ec1c5a7d295193a620f9022ff242cd5a64cb92e5d6afdd25630030b9dfd4863` |
| A01 | `01-requirements/CORE-REQUIREMENTS.md` | 3478 | `296c62912af43d16e94dc2c394c96a934199521720f543b22e47037c691ca03d` |
| A01 | `06-project-state/PROJECT-STATUS.md` | 1763 | `4d7287de08910e4ef8993417db52ba8b4546310178debc45b27939697385cf75` |
| A01 | `03-protocols/AGENT-COLLABORATION.md` | 1548 | `f9fd479d4f4adba540899553212c7a7473109554deb50aeadd8d4524ccf110cd` |
| A01 | `03-protocols/CORE-WORK-PROTOCOL.md` | 1893 | `909028aad552a72614771c83ac95dbc088c721b85bbefc2c391bcf41619af427` |
| A01 | `03-protocols/MEMORY-AND-STATE.md` | 1552 | `e9fd1ac93c1f460187a7032a6e576806ea29e646cc8565e1aaa8cd210f755c6d` |
| A01 | `03-protocols/TOOLS-PERMISSIONS.md` | 1654 | `0eb0a25b3c56b8107c0e87d4a527a34821f6f9c0dddb29654e02b459559cfdce` |
| A01 | `04-quality/ACCEPTANCE-TESTS.md` | 2170 | `88a1767571404b7829252e002c9555c6dcad03f8f9849041971dbd0ef05e60d8` |
| A01 | `00-governance/SOURCE-BASELINE-V1.0.md` | 4184 | `6c654a5a89240a516e8c79545d400ad79d06b9b477ec958f8200ebf319e4ee03` |
| A01 | `00-governance/V1.0-AUDIT.md` | 4122 | `4739f668c5520d02f884a83f1d2df1f8f2d7918e2e907fb0eb1f075f8d489481` |
| A01 | `05-platform/PLATFORM-ADAPTER-CONTRACT.md` | 1316 | `52a40e0240aa773757ccba30879573bc252897bd42559578161540420921b723` |
| H11 | `README.md` | 676 | `c1ea75c689cd8899a7d061058166566a3037e96d4006d6701db0e28d6aa1522a` |
| H11 | `02-dsh-execution/DSH-EXECUTION-BRIEF.md` | 4207 | `2669de1658be09551fdba624aaf3060b125ee4e77b9ebc0a30228bbf7bfd0aeb` |
| H11 | `01-core/AI-POS-MASTER-PROMPT-V1.1.md` | 13010 | `615e34fa21fd0866a354b4a9f427dd6094713974d87d7893cce3cc23150ed1a6` |
| R02 | `AI-POS-Core-Architecture-Pack-0.1/README.md` | 1881 | `67ed4d0745aecc0d0355353d875013fdaea7a74dae16d98074749c61e387170a` ⚠ 与 A01:README.md 完全相同 |
| R02 | `AI-POS-Core-Architecture-Pack-0.1/02-architecture/CORE-ARCHITECTURE.md` | 2845 | `8ec1c5a7d295193a620f9022ff242cd5a64cb92e5d6afdd25630030b9dfd4863` ⚠ 与 A01:02-architecture/CORE-ARCHITECTURE.md 完全相同 |
| R02 | `AI-POS-Core-Architecture-Pack-0.1/01-requirements/CORE-REQUIREMENTS.md` | 3478 | `296c62912af43d16e94dc2c394c96a934199521720f543b22e47037c691ca03d` ⚠ 与 A01:01-requirements/CORE-REQUIREMENTS.md 完全相同 |
| R02 | `AI-POS-Core-Architecture-Pack-0.1/06-project-state/PROJECT-STATUS.md` | 1763 | `4d7287de08910e4ef8993417db52ba8b4546310178debc45b27939697385cf75` ⚠ 与 A01:06-project-state/PROJECT-STATUS.md 完全相同 |
| R02 | `AI-POS-Core-Architecture-Pack-0.1/03-protocols/AGENT-COLLABORATION.md` | 1548 | `f9fd479d4f4adba540899553212c7a7473109554deb50aeadd8d4524ccf110cd` ⚠ 与 A01:03-protocols/AGENT-COLLABORATION.md 完全相同 |
| R02 | `AI-POS-Core-Architecture-Pack-0.1/03-protocols/CORE-WORK-PROTOCOL.md` | 1893 | `909028aad552a72614771c83ac95dbc088c721b85bbefc2c391bcf41619af427` ⚠ 与 A01:03-protocols/CORE-WORK-PROTOCOL.md 完全相同 |
| R02 | `AI-POS-Core-Architecture-Pack-0.1/03-protocols/MEMORY-AND-STATE.md` | 1552 | `e9fd1ac93c1f460187a7032a6e576806ea29e646cc8565e1aaa8cd210f755c6d` ⚠ 与 A01:03-protocols/MEMORY-AND-STATE.md 完全相同 |
| R02 | `AI-POS-Core-Architecture-Pack-0.1/03-protocols/TOOLS-PERMISSIONS.md` | 1654 | `0eb0a25b3c56b8107c0e87d4a527a34821f6f9c0dddb29654e02b459559cfdce` ⚠ 与 A01:03-protocols/TOOLS-PERMISSIONS.md 完全相同 |
| R02 | `AI-POS-Core-Architecture-Pack-0.1/04-quality/ACCEPTANCE-TESTS.md` | 2170 | `88a1767571404b7829252e002c9555c6dcad03f8f9849041971dbd0ef05e60d8` ⚠ 与 A01:04-quality/ACCEPTANCE-TESTS.md 完全相同 |
| R02 | `AI-POS-Core-Architecture-Pack-0.1/00-governance/SOURCE-BASELINE-V1.0.md` | 4184 | `6c654a5a89240a516e8c79545d400ad79d06b9b477ec958f8200ebf319e4ee03` ⚠ 与 A01:00-governance/SOURCE-BASELINE-V1.0.md 完全相同 |
| R02 | `AI-POS-Core-Architecture-Pack-0.1/00-governance/V1.0-AUDIT.md` | 4122 | `4739f668c5520d02f884a83f1d2df1f8f2d7918e2e907fb0eb1f075f8d489481` ⚠ 与 A01:00-governance/V1.0-AUDIT.md 完全相同 |
| R02 | `AI-POS-Core-Architecture-Pack-0.1/05-platform/PLATFORM-ADAPTER-CONTRACT.md` | 1316 | `52a40e0240aa773757ccba30879573bc252897bd42559578161540420921b723` ⚠ 与 A01:05-platform/PLATFORM-ADAPTER-CONTRACT.md 完全相同 |
| R02 | `AI-POS-Core-V1.1-Handoff/README.md` | 676 | `c1ea75c689cd8899a7d061058166566a3037e96d4006d6701db0e28d6aa1522a` ⚠ 与 H11:README.md 完全相同 |
| R02 | `AI-POS-Core-V1.1-Handoff/02-dsh-execution/DSH-EXECUTION-BRIEF.md` | 4207 | `2669de1658be09551fdba624aaf3060b125ee4e77b9ebc0a30228bbf7bfd0aeb` ⚠ 与 H11:02-dsh-execution/DSH-EXECUTION-BRIEF.md 完全相同 |
| R02 | `AI-POS-Core-V1.1-Handoff/01-core/AI-POS-MASTER-PROMPT-V1.1.md` | 13010 | `615e34fa21fd0866a354b4a9f427dd6094713974d87d7893cce3cc23150ed1a6` ⚠ 与 H11:01-core/AI-POS-MASTER-PROMPT-V1.1.md 完全相同 |
| R02 | `AI-POS-COMBINED-REVIEW-PACK-0.2/INTEGRATION-README.md` | 957 | `54e2c5b0ee965db1ae5b5ee28cd6b5153df5dcc5696fe44e4c0ddc136b1a39ae` |
| D03 | `MANIFEST.txt` | 1632 | `86b5416de643a27150e949204fe39d9d91471f5122e401d062745bce70836075` |
| D03 | `README.md` | 1599 | `4d2139d997bd9132195d30bf8bf5da52e4fd7531219a89a8dd46f47e2177620b` |
| D03 | `00-governance/BASELINE-COMPARISON.md` | 792 | `1344600c2ec1533c18c9d7ac71cfb7ccb4efcca141f16c60a9858e9b797e621c` |
| D03 | `00-governance/CHANGELOG.md` | 439 | `c61860e2cf4fe7ea69c5f8f36e1cab194d70dcfbecab6e6bdb631bc63315bd69` |
| D03 | `00-governance/PROJECT-DECISIONS.md` | 1056 | `bd1be919063d1280ecfbcbd41d758f9b0883c6f7f2010b4110120b440c3efe93` |
| D03 | `00-governance/V1.0-BASELINE-RECONSTRUCTION.md` | 2678 | `a2f3582bb0eba091dc799bdaf2aff7c6216f8a7f247e90b8a0c61c2b8093e6d9` |
| D03 | `01-master-prompt/AI-POS-MASTER-PROMPT-V1.1-CANDIDATE.md` | 8514 | `ff5e26909082c854f9128020ce146e691a90dee2d7f9bc1fc2e1ade6d12f60e4` |
| D03 | `02-architecture/CORE-ARCHITECTURE.md` | 1863 | `bf5cc34061bd9dd3d41df2cf7372fc2af450320692351053e9cf977a94a9d710` |
| D03 | `03-protocols/CORE-WORK-PROTOCOL.md` | 804 | `4864477298a953a58070b5ea9b7b7111d03bd60ddf71480c3b3c6d9521e0b662` |
| D03 | `03-protocols/MEMORY-AND-STATE.md` | 971 | `de35c1492a545130353783036c2d96da2e9014b0724ccc3a688c8933c271de07` |
| D03 | `03-protocols/TOOLS-PERMISSIONS.md` | 910 | `586f2064f790af47a19f7f90808e0ff48ed4b854677e57875efd0722b7325757` |
| D03 | `04-collaboration/AGENT-COLLABORATION.md` | 1034 | `4c64d8cb7a6d874541a3a5113465e4a9673df7d1184d229353f5b9a13fdd298a` |
| D03 | `05-platform/PLATFORM-ADAPTER-CONTRACT.md` | 917 | `4fa96281980a385196e3a2cb60fa23942b0d7400c6b06449ca156dea488fdd17` |
| D03 | `06-quality/ACCEPTANCE-TESTS.md` | 1712 | `53a383e8e5ad2d8653d4d0737c8a346197aa89b1f7c1f3fecb80b8f6e98aae15` |
| D03 | `07-execution/DSH-EXECUTION-BRIEF.md` | 2529 | `6c2eb7ef8096d018da8f35e2ae80decdea386f2425a19a72d70e18b476f2b29f` |
| D03 | `08-operations/DEPLOYMENT-AND-USER-GUIDE.md` | 1448 | `fd7578c8d08970f6fd7a1637cca096c355b8733e8f166471dd79049d0bb814a1` |
| D03 | `09-project-state/PROJECT-STATUS.md` | 1002 | `c197e01db5c2b6ae949a89f89d98b9161a27b573e2d757eaba7cee984657466d` |

## 1.3 跨包重复情况（去重结论）

R02 是 A01 + H11 的无损合并包：其 15 个文件与 A01/H11 对应文件 SHA-256 完全一致（字节级相同），未发现内容漂移。
因此**有效独立版本只有 3 个**：A01（架构+基线原文）、H11（V1.1 候选）、D03（0.3 统一交付）。R02 不构成第 4 个版本。

| 版本 | 角色 | 关键内容 |
|---|---|---|
| A01 | 基线持有者 | **含 V1.0 完整原文** `SOURCE-BASELINE-V1.0.md`（4184 B / 131 行 / sha256 6c654a5a…）+ V1.0 审计 + Core 需求 |
| H11 | V1.1 正文（中文，13010 B / 247 行 / sha256 615e34fa…） | 13 章完整版 V1.1 候选稿 + 中文 DSH 任务书 |
| D03 | 0.3 统一交付 | V1.1 **英文缩写候选稿**（8514 B / 133 行 / sha256 ff5e2690…）+ 精简协议 + 重建基线（非原文） |

## 1.4 完整性判定

| 检查项 | 结果 | 证据 |
|---|---|---|
| 四包均可解压 | PASS | unzip -l 全部成功 |
| D03 自带 MANIFEST.txt 16 条校验 | PASS | `sha256sum -c MANIFEST.txt` 16/16 OK |
| D03 内部路径引用可解析 | PASS | README 引用的 7 个路径全部存在 |
| D03 内部 Markdown 超链接 | NOT_APPLICABLE | 全包 0 个 `](` 链接，仅用反引号路径 |
| **V1.0 完整原文可获得** | **PASS（关键）** | 见 `00-immutable-baseline/SOURCE-BASELINE-V1.0.md`，与 A01 原件 cmp 字节一致 |
| D03 声称「V1.0 原文不可得」 | **FAIL — 该前提不成立** | D03 README 第 2 段、PROJECT-STATUS、V1.0-BASELINE-RECONSTRUCTION 均以此为前提，但原文就在用户同批交付的 A01 包内 |

## 1.5 关键结论

> D03 的核心免责前提（「完整 V1.0 原文在生成时不可得」）**为假**。V1.0 原文自 A01 起就在交付链内，
> 且 A01 README 明确写「records the actual V1.0 source」。0.3 之所以降级为「重建摘要」，是**没有读取同批交付的 0.1 包**，
> 不是客观缺失。因此本次审计**具备完整基线条件**，可以也必须做逐条差异，不能停在「无法核对」。
