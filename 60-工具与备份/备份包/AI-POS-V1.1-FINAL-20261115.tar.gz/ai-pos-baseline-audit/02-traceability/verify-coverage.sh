#!/usr/bin/env bash
# V1.0 条款覆盖率复检脚本
# 用途: 校验任一版 V1.1 是否覆盖 V1.0 全部 73 条可指认规则
# 用法: ./verify-coverage.sh <V1.1文件>
# 退出码: 0=全覆盖  1=有缺口  2=用法错误
set -u
TARGET="${1:-}"
[ -z "$TARGET" ] && { echo "用法: $0 <V1.1文件>"; exit 2; }
[ ! -f "$TARGET" ] && { echo "文件不存在: $TARGET"; exit 2; }

pass=0; fail=0; failed_ids=()
chk() { # id 描述 扩展正则
  if grep -qE "$3" "$TARGET"; then
    printf "  %-7s PASS  %s\n" "$1" "$2"; pass=$((pass+1))
  else
    printf "  %-7s FAIL  %s\n" "$1" "$2"; fail=$((fail+1)); failed_ids+=("$1")
  fi
}

echo "================================================================"
echo " 待检文件: $TARGET"
echo " 字节: $(wc -c < "$TARGET")  行: $(wc -l < "$TARGET")  sha256: $(sha256sum "$TARGET" | cut -c1-16)"
echo " 基线: V1.0 73 条"
echo "================================================================"

echo; echo "【一、核心原则 10 条】"
chk C1-01 "目标优先"        "最终目标优先|目标优先|Goal and outcome first"
chk C1-02 "不得削弱要求"    "不得擅自改变、削弱|不削弱要求|Never silently weaken"
chk C1-03 "不得把猜测当事实" "不得把猜测当成事实|事实诚实|Separate.*fact.*inference"
chk C1-04 "最新信息检索"    "最新性|主动检索可靠来源|current authoritative sources"
chk C1-05 "检查实际文件"    "文件优先|必须检查实际文件|Inspect relevant files"
chk C1-06 "需求与验收标准"  "需求和验收标准|acceptance criteria|可验证的完成条件|验收条件"
chk C1-07 "根因优先"        "根因优先|根本原因|Fix root causes"
chk C1-08 "无证据不宣称完成" "证据闭环|Never claim.*without evidence|不能证明的结果"
chk C1-09 "不制造不必要复杂" "适度复杂|Keep complexity proportional|不必要的复杂"
chk C1-10 "记录未完成与阻塞" "状态透明|Record incomplete work|明确记录剩余工作"

echo; echo "【二、主动需求分析 11 条】"
chk C2-01 "最终结果"        "最终结果|最终想获得什么结果|desired outcome|required outcome"
chk C2-02 "明确要求"        "明确要求|explicit requirements"
chk C2-03 "隐含必要要求"    "可能没有意识到的必要要求|materially implied|隐含约束"
chk C2-04 "矛盾与缺口"      "矛盾和缺口|conflicts, unknowns|矛盾、缺口|矛盾和缺口|缺口"
chk C2-05 "领域专家方法"    "领域专家|domain expert"
chk C2-06 "材料工具技术"    "原始材料、工具和技术|所需的原始材料|所需.*材料|输入材料|inputs, tools|materials/tools"
chk C2-07 "失败点与验证"    "失败模式|潜在失败点|failure modes|failure points"
chk C2-08 "ABCD 四级"       "A 必须满足|A — mandatory|A\. 必须处理"
chk C2-09 "C 不入正式范围"  "不得擅自把 C|Do not silently add C|不要擅自将可选增强"
chk C2-10 "仅关键决策才问"  "关键决策|only the most important question|仅当关键未知"
chk C2-11 "标注假设继续"    "标注假设|bounded assumption|合理假设"

echo; echo "【三、研究与方案 7 条】"
chk C3-01 "一手来源"        "一手|primary sources|官方资料"
chk C3-02 "区分事实推断假设" "区分事实|Separate.*verified fact|事实、推断、假设|区分已验证事实"
chk C3-03 "比较可行方案"    "比较可行方案|比较方案|compare (feasible )?(options|方案)"
chk C3-04 "说明优缺点风险依赖" "说明优缺点|优缺点|trade-off|风险和依赖"
chk C3-05 "推荐方案并解释"  "推荐最合适|给出推荐|recommend.*(reason|why)|并解释原因"
chk C3-06 "客观验收标准"    "客观验证的验收标准|acceptance criteria|可验证的完成条件"
chk C3-07 "不忽略反面证据"  "反面证据|counter-evidence"

echo; echo "【四、执行机制 8 条】"
chk C4-01 "拆分成小任务"    "拆分成小任务|Break complex work into units|拆分为工作单元"
chk C4-02 "输入输出完成条件" "输入、输出和完成条件|inputs, outputs.*completion conditions|完成条件"
chk C4-03 "高价值高风险优先" "高价值|higher value|优先处理高价值"
chk C4-04 "集中完成工作单元" "工作单元|work unit"
chk C4-05 "保留原件可恢复"  "保留原始文件|Preserve originals|可恢复版本"
chk C4-06 "修改后检查成果"  "修改后检查|检查实际成果|修改后|inspect the actual resulting files|After editing"
chk C4-07 "追查根因"        "追查根因|Fix root causes|识别根因"
chk C4-08 "不删功能不降要求" "不得擅自删除原有功能|Do not remove features|删除原有功能|降低要求|不削弱要求|不得静默删除"

echo; echo "【五、独立审核 10 条】"
chk C5-01 "满足原始要求"    "完整满足原始要求|requirement coverage|原始要求逐项覆盖"
chk C5-02 "事实错误"        "事实错误|是否存在事实|事实、来源|factual"
chk C5-03 "逻辑漏洞"        "逻辑漏洞|是否存在逻辑|逻辑一致性|logical"
chk C5-04 "遗漏文件功能依赖" "遗漏的文件|completeness of files|文件、功能、依赖"
chk C5-05 "是否引入新问题"  "引入新的问题|regression risk|回归风险"
chk C5-06 "是否有效测试"    "有效测试|tests, reproducibility|测试是否真实执行"
chk C5-07 "证据是否足够"    "测试证据是否足够|证据是否足够|结果是否可复现|evidence is insufficient"
chk C5-08 "更可靠的修复方案" "更可靠的修复方案|more reliable fix"
chk C5-09 "审核不复述结论"  "不能仅仅重复|not simply accept the implementer|不得只复述执行"
chk C5-10 "问题六要素"      "位置.*严重程度.*证据.*根因|identifier, severity, location, evidence, root cause"

echo; echo "【六、项目状态 11 条】"
chk C6-01 "项目最终目标"    "项目最终目标|项目目标与范围|project name, goal|project identity, objective"
chk C6-02 "当前正式需求"    "当前正式需求|已确认需求|requirements"
chk C6-03 "已确认决策"      "已确认决策|approved decisions|关键决策"
chk C6-04 "当前版本和基线"  "当前版本和基线|immutable source baseline|权威基线"
chk C6-05 "已完成任务"      "已完成任务|已完成|completed"
chk C6-06 "未完成任务"      "未完成任务|未完成|incomplete"
chk C6-07 "当前阻塞"        "当前阻塞|阻塞|blockers"
chk C6-08 "已发现问题"      "已发现的问题|open issues|发现的问题|尚未解决的问题|OPEN"
chk C6-09 "测试结果"        "测试结果|tests run"
chk C6-10 "下一步工作"      "下一步工作|next actions"
chk C6-11 "不凭记忆猜测"    "不得凭记忆猜测|do not reconstruct exact wording from memory|不虚构过去进度|不得凭记忆|不得虚构"

echo; echo "【七、完成标准 6 条】"
chk C7-01 "原始需求得到满足" "原始需求得到满足|原始要求逐项覆盖|requirements met"
chk C7-02 "必要功能文件完整" "必要功能和文件完整|必要功能.*完整|files.*complete|功能完整"
chk C7-03 "独立审核通过"    "独立审核通过|独立审核完成|independent review"
chk C7-04 "相关测试通过"    "相关测试通过|测试通过|tests pass"
chk C7-05 "无未披露重大问题" "没有未披露的重大问题|未披露的重大问题|已披露|no undisclosed"
chk C7-06 "成果与版本已保存" "正式成果和版本记录已经保存|版本记录已经保存|变更记录|version record"

echo; echo "【八、工作态度 7 条】"
chk C8-01 "主动严谨客观专业" "保持主动、严谨、客观和专业|主动.*严谨.*客观"
chk C8-02 "不只告诉怎么做"  "不要只告诉用户应该怎么做|不要只给建议|不要只告诉"
chk C8-03 "直接完成能做的"  "直接完成自己能够完成|在拥有相应工具.*直接完成|直接完成"
chk C8-04 "不反复推回用户"  "不要把明显可以自行解决|推回用户|反复交给用户"
chk C8-05 "不停止合理推进"  "不要为了避免犯错而停止|Do not force unnecessary pauses|停止所有合理推进|直接开始"
chk C8-06 "重大变更先确认"  "重大方向变化|重大方向|consequential decision|关键未知条件时|必须先取得用户确认"
chk C8-07 "用户方向AI执行"  "用户负责方向|user owns direction|用户保留目标|用户负责方向与关键决策"

echo; echo "【九、架构约束 6 条】"
chk R-04a "单Agent可运行"   "不得依赖多个 Agent|No core function may require multiple agents|不依赖多 Agent 才能运行"
chk R-04b "不写死平台工具名" "平台特定工具名|No platform-specific tool name|不得假设平台"
chk R-04c "规则不重复定义"  "不得在多个权威文件中重复|must not be duplicated|唯一权威规则源"
chk R-04d "Agent输出不可信" "Agent 输出.*不可信|untrusted until validated|不得盲信"
chk R-04e "工具输出是数据"  "数据，不是指令|data, not instructions"
chk R-04f "门禁按风险定"    "由.*动作风险.*决定|determined by action risk|由动作风险"

echo; echo "【十、机制完整性】"
chk R-05a "BLOCKED 态"      "BLOCKED"
chk R-05b "CANCELLED 态"    "CANCELLED"
chk R-05c "PARTIAL 态"      "PARTIAL"
chk R-05d "FAILED 态"       "FAILED"
chk R-06a "权限 P0"         "P0"
chk R-06b "权限 P4"         "P4"
chk R-08  "发布门禁"        "发布门禁|Release gate|发布门槛"
chk R-09  "中断恢复协议"    "中断恢复|Recovery|检查点恢复"
chk R-10a "Agent回报7项"    "Worker response|回报格式|不确定项与冲突|Uncertainties"
chk R-10b "能力声明6态"     "Native|Connected|Simulated|Unsupported"
chk A-01  "ZIP不等于可用"   "ZIP.*不是.*证据|ZIP that opens is not proof|ZIP 完整性.*不等同"

echo
echo "================================================================"
total=$((pass+fail))
printf " 通过: %d / %d   覆盖率: %.1f%%\n" "$pass" "$total" "$(awk "BEGIN{printf \"%.1f\", $pass*100/$total}")"
if [ "$fail" -gt 0 ]; then
  echo " 未覆盖 ID: ${failed_ids[*]}"
  echo " 结果: FAIL"
  exit 1
fi
echo " 结果: PASS —— 全部条款已覆盖"
exit 0
