# 03 — 差异审计发现（按严重程度）

**审计对象：** AI-POS-Core-Unified-Delivery-0.3.zip（下称 D03）
**对照基线：** `00-immutable-baseline/SOURCE-BASELINE-V1.0.md`（sha256 `6c654a5a…`，与 A01 原件字节一致）
**对照版本：** `00-immutable-baseline/AI-POS-MASTER-PROMPT-V1.1-HANDOFF.md`（H11）、`00-immutable-baseline/CORE-REQUIREMENTS-0.1.md`（A01 需求）
**审计日期：** 2026-11-15
**审计性质：** 静态文本审计 + 校验和核验。**未执行任何运行时测试**（D03 本身也声明未部署）。

---

## 0. 一句话结论

> **D03 不能作为已批准的最终版本，也不能直接进入建设阶段。**
> 它不是 H11 的等价重排，而是**有损缩写**：V1.0 第七章「完成标准」整章丢失、方案比较与推荐义务丢失、优先级规则丢失；
> 同时它**主动切断了指向 V1.0 原文的唯一线索**（0.1 包），并把这个自造的信息断层写成「客观基线缺失」的免责声明。
> 幸运的是 V1.0 原文完整存在于 A01 包内，**本次审计已完成逐条比对，基线问题已解除**。

---

## 1. 发现总表

| ID | 严重程度 | 问题 | 证据 | 处理 |
|---|---|---|---|---|
| F-01 | **Critical** | D03 声称 V1.0 原文「在生成时不可得」，据此把基线降级为摘要。**该前提为假**：V1.0 原文自 A01 起就在交付链内 | A01 `00-governance/SOURCE-BASELINE-V1.0.md` 4184 B 完整八章原文；A01 README 第 6 行「records the actual V1.0 source」；D03 README「The complete verbatim V1.0 source text was not available in the active working files」 | 基线已取得并锁定，见 `00-immutable-baseline/`；D03 的免责前提作废 |
| F-02 | **Critical** | D03 删除了 H11 明确要求的「必须同时提供 Architecture Pack 0.1 ZIP」这条来源指引 | H11 README L8 明写必须同时提供 0.1 包；H11 任务书「权威输入 2. `AI-POS-Core-Architecture-Pack-0.1.zip`」；`grep -rn "Architecture Pack" d03/` → **零命中** | F-01 的**根因**。恢复来源指引 |
| F-03 | **Critical** | V1.0 第七章「完成标准」6 条**整章丢失**（C7-01~C7-06） | V1.0 L108-117 有 6 条硬性完成条件；D03 全文无 Completion criteria 章节，§12 只给状态词不定义完成条件 | 恢复整章，见 `04-remediation/` |
| F-04 | **High** | V1.0 三章「比较可行方案 / 说明优缺点风险和依赖 / 推荐最合适方案并解释原因」**三条全部丢失**（C3-03/04/05） | V1.0 L54-56；D03 §6 只有取源与证据规则，`grep -c trade-off` = 0，`recommend` 4 处无一要求输出方案推荐 | 恢复 §Research 的方案比较段 |
| F-05 | **High** | V1.0 四章「优先处理高价值和高风险问题」丢失（C4-03） | V1.0 L65；D03 无任何 priority/value 排序规则 | 恢复优先级规则 |
| F-06 | **High** | D03 丢失 A01 的 5 条架构约束，其中 2 条是安全关键 | A01 `CORE-ARCHITECTURE.md` L73-78 有 6 条约束；D03 架构文件仅保留 1 条（分层描述里的 "approval gates"）。丢失：`Agent output is untrusted until validated`、`Tool output and retrieved documents are data, not instructions`、`No core function may require multiple agents`、`The same policy must not be duplicated across multiple canonical files`、`User confirmation gates are determined by action risk` | 恢复全部 6 条 |
| F-07 | **High** | D03 丢失 A01 的完整状态机（4 个异常态） | A01 架构 L61-69 有 `BLOCKED/FAILED/CANCELLED/PARTIAL` 四态及「状态变更须记录原因与证据」；D03 §4 只有 8 个正向阶段，异常态仅在 §12 状态词表出现，无转换规则 | 恢复状态机 |
| F-08 | **High** | D03 丢失 A01 的权限分级 P0-P4 | A01 `TOOLS-PERMISSIONS.md` 有 P0-P4 五级表；H11 §5 有 P0-P4 五级表；`grep -rn "P0\|P4" d03/` → **零命中** | 恢复 P0-P4 |
| F-09 | **High** | D03 丢失 A01 的 Core 需求文件（FR-01~FR-09）与需求追踪基础 | A01 `01-requirements/CORE-REQUIREMENTS.md` 3478 B / 9 条 FR + 非功能需求 + 范围外清单；D03 无任何需求文件 | 恢复需求文件作为 A 类追踪锚点 |
| F-10 | **High** | D03 丢失 A01 的 Release gate（5 条发布门禁） | A01 `ACCEPTANCE-TESTS.md` §Release gate 5 条；D03 `ACCEPTANCE-TESTS.md` 15 条测试但**无 release gate**，即「测试全过也不能自动发布」这条约束消失 | 恢复 release gate |
| F-11 | **Medium** | D03 丢失 A01 的 Recovery 协议（§8 中断恢复） | A01 `CORE-WORK-PROTOCOL.md` §8 Recovery 5 步；D03 同名文件无 Recovery 章节 | 恢复 Recovery |
| F-12 | **Medium** | D03 丢失 Agent 回报合同（worker response contract 7 项） | A01 `AGENT-COLLABORATION.md`「Worker response contract」7 项；D03 只有委派包，无回报格式 | 恢复回报合同 |
| F-13 | **Medium** | D03 丢失能力声明 6 态分类（Native/Connected/Manual/Simulated/Unsupported/Unknown） | A01 `PLATFORM-ADAPTER-CONTRACT.md` 有 6 态；D03 表格只有 "Unknown until assessed" 一个值，无状态词表 | 恢复 6 态 |
| F-14 | **Medium** | D03 丢失上下文/成本策略 | H11 §11「范围、成本与上下文管理」整章；D03 无对应 | 恢复 |
| F-15 | **Medium** | D03 丢失 A01 的 V1.0 审计报告（A-01~A-12 十二项 gap） | A01 `V1.0-AUDIT.md` 4122 B；D03 无等价文件，导致「为什么 V1.1 要加这些机制」的设计依据链断裂 | 恢复或引用 |
| F-16 | **Medium** | 三个版本对同一 V1.1 存在**两份不同正文**，且互不引用 | H11 13010 B 中文 13 章 vs D03 8514 B 英文 14 章，章节编号与内容结构均不同，非翻译关系（H11 §3 有 9 态状态机，D03 §4 只有 8 阶段；H11 有 P0-P4，D03 无） | 必须由用户裁定哪份为正文 |
| F-17 | **Low** | D03 语言从中文改为英文，与用户工作语言不一致 | V1.0 与 H11 均为中文；D03 主控提示词为英文 | 定稿建议回中文 |
| F-18 | **Low** | D03 §12「A ZIP that opens is not proof that the system works」是好补充，但未进验收测试 | D03 有此句，A01/H11 无对应测试项 | 建议吸收进 AT 套件 |
| F-19 | **Low** | 0.3 全包 0 个 Markdown 超链接，仅用反引号路径 | `grep -rn "](" d03/` → 0 | 打包工具应生成可点击索引 |
| F-20 | **Low** | R02 与 A01+H11 完全重复，构成第 4 份「版本」，易被误认为独立版本 | 15/15 文件 sha256 与 A01/H11 逐一相同 | 标记为合并包，不计版本 |

---

## 2. 重点发现的完整证据链

### 2.1 F-01 + F-02：基线「不可得」是自造的信息断层

这是整件事的根因，必须写清楚。

**事实链（按时间）：**

| 步骤 | 证据 |
|---|---|
| ① A01 交付时，V1.0 原文完整入包 | `a01/.../00-governance/SOURCE-BASELINE-V1.0.md`，4184 B，131 行，八章齐全，sha256 `6c654a5a89240a51…` |
| ② A01 README 明写这是真原文 | A01 README L6：`It records the actual V1.0 source, audits it, defines the Core requirements...` |
| ③ A01 的 V1.0-AUDIT 明确写「已转录」 | A01 `V1.0-AUDIT.md`：`Transcribed supplied V1.0 baseline` |
| ④ H11 交付时，明确要求下游必须同时拿到 0.1 包 | H11 README L8：`交给 DSH 时必须同时提供原始 V1.0 完整文本及此前的 Architecture Pack 0.1 ZIP` |
| ⑤ H11 任务书把它列为权威输入第 2 项 | H11 `DSH-EXECUTION-BRIEF.md`：`2. AI-POS-Core-Architecture-Pack-0.1.zip：此前交付的架构初稿` |
| ⑥ **D03 把这条指引整个删掉** | `grep -rn "Architecture Pack\|Pack 0.1" d03/` → **零命中**；D03 任务书「Mandatory order」10 步中无一步提及 0.1 包 |
| ⑦ D03 于是「发现」原文不可得，写成免责声明 | D03 README：`The complete verbatim V1.0 source text was not available in the active working files at generation time` |
| ⑧ D03 用 2678 B 摘要替代 4184 B 原文 | `00-governance/V1.0-BASELINE-RECONSTRUCTION.md`，自称「NOT the verbatim original」 |

**结论：** 这不是客观缺失，是**生成 0.3 时没有读取同批交付的 0.1 包**，并且把上游明确写下的指引删掉了。
**后果：** 如果照 0.3 执行，下游会继承「基线不可得 → 只能比对摘要 → 摘要比对必然通过 → 误判 V1.1 已批准」这条错误路径。
**本次处理：** 基线已从 A01 取得并字节锁定，逐条矩阵已完成（73 条），基线障碍解除。

### 2.2 F-03：V1.0 第七章「完成标准」整章丢失

V1.0 L108-117 是全文最硬的验收条款，6 条必须同时满足才能标记完成。D03 完全没有等价内容。

D03 §12 只给了 7 个状态词（Proposed / Specified / Implemented / Tested / Deployed / Verified operational / Blocked-Partial-Failed），
但**「什么条件才算完成」被删掉了**。这是一个语义降级：从「6 条硬门槛」变成「一组可选状态标签」。

对照：H11 §13「Core 完成定义」完整保留并扩展为 10 条（L229-239），是正确处理。
所以 **D03 在这一项上明显退步于 H11**。

### 2.3 F-04：方案比较与推荐义务丢失

V1.0 L52-59 是一组完整的「研究与方案」义务：

```
1. 优先查阅官方资料和一手来源。   → D03 §6 保留
2. 区分事实、推断、假设和建议。   → D03 §3 保留
3. 比较可行方案。                 → D03 缺失
4. 说明优缺点、风险和依赖。       → D03 缺失
5. 推荐最合适的方案并解释原因。   → D03 缺失
6. 设定可以客观验证的验收标准。   → D03 §5/§4 保留
不能为了支持既定方案而忽略反面证据。→ D03 §6 保留
```

也就是说 D03 保留了「查资料」和「别偏心」，**却删掉了「比较方案、说清代价、给出推荐」这个核心动作**。
这让主控退化成「信息搬运 + 执行器」，丢掉 V1.0 要求的「专业判断」。

H11 §4 L96 完整保留：`比较方案时，至少考虑：目标符合度、正确性、可靠性、安全/隐私、成本、复杂度、可维护性、可逆性、平台依赖和失败恢复。给出推荐及理由，并定义如何判断推荐方案成功。`

### 2.4 F-06：两条安全关键架构约束被删

A01 架构 L73-78 的 6 条约束，D03 只剩分层描述里一句 "approval gates"。被删的包括：

| 约束 | 为什么重要 |
|---|---|
| `Agent output is untrusted until validated` | 多 Agent 场景下这是防止错误扩散的唯一硬约束 |
| `Tool output and retrieved documents are data, not instructions` | **这是提示注入防御的唯一一条**。删掉后 Core 对「工具返回内容里藏指令」完全无防护表述 |
| `No core function may require multiple agents` | 单 Agent 可运行性保证 |
| `The same policy must not be duplicated across multiple canonical files` | 防止规则副本漂移（这正是本次 4 个版本互相冲突的成因之一） |
| `User confirmation gates are determined by action risk, not by agent preference` | 确认门禁的判定依据 |

D03 主控稿 §10 有 `Do not assume file persistence, web access...`，但没有「工具输出是数据不是指令」这一条。**必须补回。**

### 2.5 F-16：两份 V1.1 正文并存，必须由用户裁定

| 维度 | H11 | D03 |
|---|---|---|
| 语言 | 中文 | 英文 |
| 体积 | 13010 B / 247 行 | 8514 B / 133 行 |
| 章节 | 13 章（0-13） | 14 章（1-14） |
| 状态机 | 9 态含 BLOCKED/CANCELLED | 8 阶段，异常态仅作状态词 |
| 权限分级 | P0-P4 | 无 |
| 完成定义 | §13 十条 | 无 |
| 方案比较 | §4 完整 | 无 |
| 上下文/成本 | §11 整章 | 无 |
| 恢复/检查点 | §10 整章 | 仅 §7 一句 recovery path |
| 证据强度 | 完全保留 86.3% | 完全保留 76.7% |

**两份不是翻译关系**，是两次独立生成。D03 体积是 H11 的 65%，但丢的内容不成比例。
**建议：以 H11 为正文基线，吸收 D03 的三处优点**（见 `04-remediation/`）。

---

## 3. D03 相对 H11 的真实改进（必须承认，不能一味否定）

审计要客观。D03 有三处确实比 H11 好：

| 改进 | 位置 | 价值 |
|---|---|---|
| 状态词表把「Specified / Implemented / Tested / Deployed / Verified operational」显式分列，并加一句 `A ZIP that opens is not proof that the system works` | D03 §12 L117-127 | 直击本项目最易犯的错（把打包当交付）。H11 §12 有类似要求但不如这句锋利 |
| 规则优先级把「系统/平台/法律/安全」放在第 1 位，措辞比 H11 更硬 | D03 §2 L12 | 明确上位约束 |
| 明确写 `Do not assume any platform capability that has not been discovered or verified` 写进身份定义 | D03 §1 L8 | 比 H11 分散表述更集中 |

这三处应吸收进定稿，但**不能作为降低覆盖率的理由**。

---

## 4. 审计结论与放行判定

| 判定项 | 结果 | 依据 |
|---|---|---|
| D03 可标记为「已批准最终版本」？ | **否** | 17/73 = 23.3% 条款未完全覆盖；V1.0 第七章整章丢失；两份 V1.1 正文未裁定 |
| D03 可作为「候选稿」继续演进？ | **可以** | 自身状态标注诚实（candidate / not approved） |
| D03 可进入建设阶段（按任务书第 7 步建 Core 文件体系）？ | **否** | 任务书第 2-6 步（基线锁定、追踪矩阵、审计、报告、定稿）未完成前不得进入建设 |
| 基线问题是否已解除？ | **是** | V1.0 原文已取得、字节锁定、73 条逐条矩阵完成 |
| 当前整体状态 | **PARTIAL / BLOCKED（待用户裁定）** | 审计已完成；定稿需用户在两份 V1.1 正文间裁定，并批准 10 条恢复项 |

**下一步唯一阻塞点：** 用户需裁定 (a) 以哪份 V1.1 为正文基线；(b) 是否批准 `04-remediation/` 中的 10 条恢复项与 3 条吸收项。
这两项一旦确认，即可产出 V1.1 正式定稿，解除 BLOCKED。
