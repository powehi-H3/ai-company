# AI-POS Core — 基线核对与差异审计包

**结论先行：** 0.3 不能当已批准定稿。V1.0 原文其实一直在交付链里（0.1 包内），
0.3 声称「原文不可得」是把上游线索删掉后自造的信息断层。本包已完成 73 条逐条比对。

**整体状态：** `PARTIAL` —— 审计完成，定稿待你裁定。

## 目录

| 目录 | 内容 | 先看哪个 |
|---|---|---|
| `05-report/FINAL-REPORT.md` | **最终报告（先看这个）** | ← 从这里开始 |
| `03-audit/AUDIT-FINDINGS.md` | 20 项发现，按严重度排序 | 想知道问题在哪 |
| `02-traceability/TRACEABILITY-V1.0-to-V1.1.md` | 73 条逐条矩阵 | 想知道具体哪条丢了 |
| `04-remediation/REMEDIATION-PLAN.md` | 16 条修复条款（15 条待执行 + 1 条已满足） | 想直接改 |
| `01-inventory/INVENTORY-AND-INTEGRITY.md` | 48 文件清单与哈希 | 想核对输入 |
| `00-immutable-baseline/` | V1.0 原文等 4 份，只读锁定 | 想比对原文 |

## 一句话数字

- V1.0 原文：4184 B / 131 行 / `6c654a5a…`（已取得，字节锁定）
- H11（V1.1 中文正文）：完全保留 **63/73 = 86.3%**
- D03（0.3 候选稿）：完全保留 **56/73 = 76.7%**
- D03 相对 H11 **净退步 14 条**，其中 V1.0 第七章「完成标准」**整章 6 条消失**

## 复检

```bash
./02-traceability/verify-coverage.sh 00-immutable-baseline/AI-POS-MASTER-PROMPT-V1.1-HANDOFF.md
./02-traceability/verify-coverage.sh 00-immutable-baseline/AI-POS-MASTER-PROMPT-V1.1-CANDIDATE-0.3.md
```

## 需要你决策两件事

1. **以哪份为正文基线？** 建议 H11（86.3% vs 76.7%，且缺的 3 条是两版共同缺陷）
2. **是否批准修复范围？** `04-remediation/` 的 10 条恢复 + 2 条吸收 + 3 条共同缺陷（合计 15 条）

确认后即可产出 V1.1 定稿，进入建 Core 阶段。
