# -*- coding: utf-8 -*-
"""适配器基类：所有 App 适配器实现这 4 个方法"""
import os, shutil, subprocess, tempfile

ROOTC = "/root/日常任务区/v9-review/rootc.py"

def root_cmd(cmd, timeout=130):
    """通过 rootd 通道执行 root 命令"""
    env = dict(os.environ, ROOTC_TIMEOUT=str(timeout))
    r = subprocess.run(["python3", ROOTC, cmd], capture_output=True, text=True, timeout=timeout+10, env=env)
    return r.returncode, r.stdout, r.stderr

class Adapter:
    name = "base"
    pkg = ""
    db_glob = ""

    def locate(self):
        """返回数据库绝对路径（在设备上）"""
        raise NotImplementedError

    def copy_db(self, dest):
        """复制 db + wal + shm 到本地 dest 目录"""
        os.makedirs(dest, exist_ok=True)
        path = self.locate()
        if not path:
            return None
        base = os.path.basename(path)
        for suffix in ["", "-wal", "-shm"]:
            src = path + suffix
            rc, out, err = root_cmd(f'cp "{src}" /sdcard/_tmp_db 2>&1; echo OK')
            if "OK" not in out:
                continue
            # 从 /sdcard 拉到本地
            local_tmp = f"/sdcard/_tmp_db"
            tgt = os.path.join(dest, base + suffix)
            try:
                shutil.copy(local_tmp, tgt)
            except Exception:
                pass
        return os.path.join(dest, base)

    def list_sessions(self, db_path):
        raise NotImplementedError

    def read_session(self, db_path, session_id):
        raise NotImplementedError
