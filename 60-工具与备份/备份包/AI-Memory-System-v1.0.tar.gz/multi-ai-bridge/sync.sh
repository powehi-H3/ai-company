#!/usr/bin/env bash
# AI 记忆同步 —— 一键完成：抓取 → 脱敏 → 导出 → 建索引
set -u
DIR="$(cd "$(dirname "$0")" && pwd)"
cd "$DIR"

echo "╔══════════════════════════════════════╗"
echo "║   AI 记忆同步                        ║"
echo "╚══════════════════════════════════════╝"

echo
echo "▶ 第 1 步：抓取对话"
python3 scripts/sync.py "$@" || { echo "✗ 抓取失败"; exit 1; }

echo
echo "▶ 第 2 步：建全文索引"
python3 scripts/index.py || { echo "✗ 索引失败"; exit 1; }

echo
echo "▶ 第 3 步：统计"
python3 - <<'PY'
import os, glob
M="/root/日常任务区/ai-memory"
for app in sorted(os.listdir(f"{M}/raw")):
    d=f"{M}/raw/{app}"
    if not os.path.isdir(d): continue
    fs=glob.glob(f"{d}/*.md")
    if not fs: continue
    sz=sum(os.path.getsize(f) for f in fs)
    print(f"  {app:10s} {len(fs):3d} 个文件  {sz/1024/1024:6.2f} MB")
db=f"{M}/index.db"
if os.path.exists(db):
    print(f"  {'索引':10s} {os.path.getsize(db)/1024/1024:6.2f} MB")
PY

echo
echo "✓ 同步完成"
echo "  知识库: /root/日常任务区/ai-memory/"
echo "  搜索:   ./search.sh \"关键词\""
