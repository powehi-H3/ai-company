# rootd-kit —— 给 dsh 的真机 root 通道

## 它解决什么问题

dsh 运行在 proot 沙箱里，**没有真机 root**，而且沙箱里的 `su` 是 Ubuntu 的假 su，
调不动 KernelSU 的 su（`/system/bin/su` 在 proot 里报 `cannot execute`）。

所以需要一个**在 proot 外面、以真 root 身份常驻的进程**，通过 `/sdcard`
和沙箱内的 dsh 通信。这就是本模块。

## 工作机制

```
开机
 └─ KernelSU 以 root 执行 /data/adb/service.d/99-rootd.sh
     └─ 调用模块 service.sh（等 /sdcard 挂载就绪，约 3~16 秒）
         └─ 启动 common/rootd-priv.sh（真 root 身份的守护进程）
             ├─ 生成/复用 token → /sdcard/rootd-out/token
             └─ 循环监听 /sdcard/rootd-in/*.req，执行后写 /sdcard/rootd-out/*.res

dsh 侧
 └─ rootc.py 写命令到 /sdcard/rootd-in → 等结果 → 读 /sdcard/rootd-out
```

**关键**：`/sdcard` 是 proot 与真机之间**唯一共享**的路径。
`/data/adb`、`/data/user/0` 在两边是**相互隔离的**，不能用来通信。

## 安装

### 手机侧
1. KSU/Magisk 刷入 `rootd-module.zip`
2. 重启手机

安装时会自动：
- 清除残留的 `remove`/`disable` 标记
- 安装启动器 `/data/adb/service.d/99-rootd.sh`

### dsh 侧
```sh
sh dsh-side/install.sh
```
装 `rootc.py` 到 `$HOME/tools/`、装插件、校验通道。

## token 安全

| 项目 | 说明 |
|---|---|
| 存放位置 | 守护内存 + `/sdcard/rootd-out/token`（开机时生成） |
| dsh 侧读取后 | 缓存到 `~/.dsh/private/rootd.token`（600），**立即删除 /sdcard 明文** |
| 轮换 | 每次重启由守护重新生成 |
| 自动恢复 | 缓存过期（126）时自动从 `/sdcard` 重读，无需人工干预 |
| 暴露窗口 | 开机后到 dsh 首次调用之间（几十秒） |

**风险**：开机那几十秒内，有完整存储访问权限的 App 理论上能读到 token 并投递命令。
只在自己信得过的设备上使用。

## 重启会掉 root 吗

**不会。** 重启会让当前守护进程消失（root 短暂断开），但开机会自动重建。
实测：重启后无需任何操作，root 自动可用。


## 一键恢复（root 掉了怎么办）

### 恢复：KSU 模块卡片的「执行」按钮

root 掉了（守护进程意外退出）时：

1. 打开 KernelSU → 模块
2. 找到 `rootd 真机 root 通道`
3. **点卡片上的「执行」按钮**

它会立刻拉起守护进程，**不用重启手机、不用开 Termux**。

**实测**：手动 kill 守护（pid 10288）→ 点执行 → 恢复成 pid 13140 → root 立刻可用。

### 关闭：KSU 里禁用模块

想主动关掉 root：

- 在 KSU 模块页关闭该模块的开关（或点「禁用」）
- 守护进程会检测到 `disable` 标记并退出（**保留 token，便于恢复**）

### 重新开启

启用模块 + **点「执行」按钮**，即可恢复（token 还在，无需重新配对）。


## 关闭 / 恢复 root 权限

### 关闭（取消 root 权限）

在 dsh 里执行：

```sh
python3 $HOME/tools/rootc.py off
```

守护进程会创建一个 `off` 标志，然后**主动退出**——此后没有任何进程以 root 身份运行，
我也无法执行任何命令。

**这个状态是持久的**：重启手机后守护仍会看到 `off` 标志并退出，root 保持关闭。

### 恢复

在 KernelSU 模块卡片点 **「执行」** 按钮。

它会自动删除 `off` 标志并重启守护进程，root 立刻恢复（token 仍保留，无需重新配对）。

### 查看状态

```sh
python3 $HOME/tools/rootc.py status
```

输出：
```
root 状态: 已开启 / 已关闭（off 标志存在）
配对: 已配对 / 未配对
守护进程: 运行中（探测成功）/ 未运行
```

### 与其它方式的区别

| 方式 | 效果 | 恢复方式 |
|---|---|---|
| `rootc.py off` | 守护退出，root 关闭（**持久**） | KSU 点「执行」 |
| KSU 禁用模块 | 守护退出（保留数据） | 启用 + 点「执行」 |
| 卸载模块 | 守护自毁 + 删全部数据 | 重新刷入 + 配对 |

## 卸载

KSU 里卸载 → 重启。

守护进程检测到模块目录消失或 `remove` 标记时，会**自己把一切删干净**：
- `/sdcard/rootd-in`、`/sdcard/rootd-out`（含 token、日志）
- `/sdcard/rootd-boot.log`
- 模块 `state/`

**不依赖 `uninstall.sh`**（部分管理器卸载时不执行它，所以由守护自毁兜底）。

dsh 侧要手动删：
```sh
rm -f $HOME/tools/rootc.py ~/.dsh/private/rootd.token
dsh plugin --profile web remove local-root-term
rm -rf $DSH_HOME/dsh-go/plugins/local-root-term
```

## 已实测验证

| 项目 | 结果 |
|---|---|
| root 身份 | `uid=0(root) ... context=u:r:ksu:s0` ✅ |
| 真机文件访问 | 可读 `/data/adb/modules`（13 个模块）✅ |
| 连测稳定性 | 10/10 ✅ |
| 开机自启 | 重启后自动可用，无需操作 ✅ |
| 守护进程数 | 1 个（有串行锁，不会重复）✅ |
| token 自动恢复 | 缓存过期后自动重读，实测通过 ✅ |

## 排障

| 症状 | 处理 |
|---|---|
| `token 不存在` | 守护没起来。`su -c 'sh /data/adb/modules/rootd_keeper/service.sh'` |
| 一直 126 | 缓存过期，客户端会自动重读；仍失败则 `rm ~/.dsh/private/rootd.token` |
| 重启后无 root | `su -c 'cat /data/adb/modules/rootd_keeper/state/service.log'` 看日志 |
| 多个守护 | `ps -A \| grep rootd-priv`，多余的 kill 掉 |
