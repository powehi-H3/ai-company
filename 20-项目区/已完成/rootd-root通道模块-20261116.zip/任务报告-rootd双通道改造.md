# rootd 主体/分身双通道改造 · 完整任务报告

**报告日期：** 2026-11-16
**报告人：** DSH 分身（user 999）
**任务起源：** 用户问「你有没有 root 权限」，发现分身无法使用本体已有的 root 通道
**最终状态：** ✅ 达成（主体/分身开关完全独立，root 双向可用）

---

## 一、任务目标

用户手机已装 KernelSU，并有一个 v9.1 模块给本体（user 0）提供 root 通道。
但分身（user 999）用不了。要求：

1. 分身在**不影响本体**的前提下，也能获得 root
2. 主体和分身的开关**必须分开**，互不影响

---

## 二、最终成果

### 2.1 核心验收项

| 验收项 | 结果 |
|---|---|
| 分身 root 可用 | ✅ `uid=0(root) context=u:r:ksu:s0` |
| 本体 root 不受影响 | ✅ 全程可用 |
| 开关独立（关分身不影响本体） | ✅ 用户真机实测 |
| 开关独立（关本体不影响分身） | ✅ 代码逻辑保证 |
| WebUI 显示正确 | ✅ 两个卡片状态准确 |
| WebUI 开关有效 | ✅ 用户真机实测 |

### 2.2 用户真机验证记录

| 操作 | 主体 | 分身 |
|---|---|---|
| 关闭分身 | 已开启（不变） | 已关闭 |
| 开启分身 | 已开启（不变） | 已开启 |

**这是最关键的证据，由用户亲自操作产生。**

---

## 三、技术改造要点

### 3.1 身份识别机制

| 概念 | 判据 | 通道路径 |
|---|---|---|
| 主体 primary | `userId = 0` | `/data/user/0/<pkg>/.../root/.dsh/rootd` |
| 分身 clone | `userId ≠ 0`（白名单） | `/data/user/999/<pkg>/.../root/.dsh/rootd` |

- uid 算法：`uid = userId × 100000 + appId`（分身 `99910458 = 999×100000+10458`）
- 身份卡：每个实例写 `instance.json`（role/userId/uid/appId/pkg/channel）
- 命令环境：守护执行时注入 `ROOTD_ROLE` / `ROOTD_USER_ID` / `ROOTD_UID`

### 3.2 准入校验（安全）

```sh
# 6 道校验，任一失败即拒绝
1. 目录存在
2. 父=root，祖父=rootfs（布局校验）
3. 属主 uid 可读（放宽：不再强制 >=10000）
4. 路径解析出 userId + pkg，pkg 必须是 dsh 本体
5. uid 自洽（属主是有效 app uid 时）：uid/100000 == 路径 userId
6. userId=0 或 userId 在白名单 CLONE_ALLOW 里
```

**防伪造验证 7/7 通过**：别人的 App、工作资料 user10、路径与属主不符的伪造场景全部拒绝。

### 3.3 开关独立性

```sh
# 每个实例只看自己的 off 文件
主体：/data/user/0/.../rootd/off
分身：/data/user/999/.../rootd/off
```

**关键修复**：删掉了守护里「全局 off 就 exit 0」的逻辑——那是「关分身=主体也没了」的根源。

---

## 四、排障过程（7 个版本，6 次方向错误）

### 4.1 时间线

| 版本 | 改动 | 结果 |
|---|---|---|
| v9.3-multi | 首次实现多实例 | 扫到 4 个候选，登记 0 个 |
| v9.4-multi | 并发派发、白名单 | 同上 |
| v9.5-split | 开关独立 | 同上 |
| v9.6-audit | 用户视角审查修复 | 同上 |
| v9.7-diag | 加扫描日志 | 发现「没有 probe 日志」 |
| v9.8-switch | WebUI 开关常驻 | UI 有了，主体仍检测不到 |
| v9.9-stable | 状态目录迁出模块 | 仍失败 |
| v9.10-diag | 拒绝原因输出到 stdout | 仍失败 |
| **v9.11-pathfix** | **补 PATH** | **✅ root 打通** |
| v9.12-scan | 去重、channel 规范化 | —— |
| v9.13-ui | 探测失败也显示开关 | —— |
| v9.14-diag | 诊断面板 | 拿到真实数据 |
| v9.18 | 每实例单独 exec | ✅ 主体显示正常 |
| v9.19-final | 心跳判定 + off 明确拒绝 | ✅ 最终版 |

### 4.2 三个真正的根因

#### 根因 1：`PATH` 缺失（v9.11 修复）

**这是最致命的。**

```sh
# service.sh 和 action.sh 都有：
export PATH=/data/adb/ksu/bin:/data/adb/magisk:/system/bin:...
# 但 rootd-priv.sh 没有！
```

守护由 init 启动，`PATH` 不含 `/system/bin`，导致：
- `basename` / `dirname` / `stat` / `date` 全部 `command not found`
- `probe_ok` 里 `p1=$(basename ...)` 为空 → 校验失败
- **`log` 依赖 `date` 也失败** → 拒绝原因全丢
- 现象：找到 4 个候选、0 个实例、**零拒绝日志**

#### 根因 2：`ksu.exec` 只返回最后一行（v9.18 修复）

**这是 WebUI 显示异常的原因。**

诊断实测（v9.14 加的诊断面板）：

```
echo LINE_A; echo LINE_B      →  只得到 "LINE_B"
echo L1; echo L2; echo L3     →  只得到 "L3"
for u in 0 999; do echo $u; done  →  只得到 "999"
```

所以 `for u in 0 999` 循环里，主体（第一个）永远被吞掉，只有分身显示。

**修法**：改成每个实例单独调用一次 `exec`。

#### 根因 3：多个守护进程同时跑（v9.16 修复）

```
10664 sh .../rootd-priv.sh
16122 sh .../rootd-priv.sh    ← 重复
20351 sh .../rootd-priv.sh    ← 重复
```

三个入口（initrc / service.sh / boot-completed.sh）同时触发，`service.sh` 的 8 秒超时兜底又自己起一个。

后果：三个进程抢同一队列，`scan` 结果互相覆盖，`instances` 永远显示旧内容。

### 4.3 我犯的错误

| 错误 | 教训 |
|---|---|
| 前 6 版都在改逻辑，没查环境前提 | **日志缺失本身就是最重要的线索**——它说明执行环境有问题 |
| 第一版探测用了点开头的文件名 | `for f in *.sh` 不匹配 `.xxx.sh` |
| 想清理多进程却把守护全杀了 | 请求正是由守护执行，杀它等于杀自己 |
| 建议删掉 `_daemon_alive` | 用更差的体验换掉误报，方向错 |
| 直接改文件测开关，绕过 UI | 真正的端到端验证必须走 UI |

### 4.4 用户的三个关键推动

1. **「你到底会不会写」** → 促使我停止盲改
2. **「先给一条命令打印 ksu.exec 原始返回」** → 才有了诊断面板，才拿到 `echo L1; echo L2 → L2` 这个决定性证据
3. **「我感觉这个模块的运行逻辑你都没搞明白」** → 促使我通读三个启动入口，发现多进程问题

---

## 五、v9.19-final 完整修复清单

| 编号 | 修复 | 来源 |
|---|---|---|
| 1 | 补 `export PATH`（脚本最前面） | 真机实测 |
| 2 | `initrc` 加 `setenv PATH` 双保险 | 真机实测 |
| 3 | `log` 不依赖 `date`（拿不到用 `[no-clock]`） | 防御性 |
| 4 | `probe_ok` 拒绝原因输出到 stdout | 审查 P0 衍生 |
| 5 | 状态目录迁到 `/data/adb/rootd_keeper/state` | 审查 P0 |
| 6 | `uninstall.sh` 不再误设 `remove` | 真机事故 |
| 7 | 自毁不删实例通道 | 真机事故 |
| 8 | 单实例互斥（杀所有同名进程） | 真机实测 |
| 9 | 去重规范化（剥 `/proc/1/root` 前缀） | 真机实测 |
| 10 | `channel` 字段写规范路径 | 真机实测 |
| 11 | `_daemon_alive` 改读心跳，不占队列 | 审查 P0 |
| 12 | `off` 时立刻返回拒绝（不死等） | 审查 P1 |
| 13 | WebUI 每实例单独 exec | 诊断实锤 |
| 14 | WebUI 开关常驻（探测失败也显示） | 用户要求 |
| 15 | 分身白名单 `CLONE_ALLOW` | 审查 P1 |
| 16 | 客户端 `--info/--role/--on/--off/--scan` | 功能完善 |

---

## 六、遗留问题

| 问题 | 状态 | 影响 |
|---|---|---|
| 守护侧 P1（off 明确拒绝）已推送未重启 | 待下次重启生效 | 无（客户端已本地拦截） |
| 多进程问题只加了互斥，未根治启动入口 | 互斥可兜住 | 低 |
| WebUI 依赖 `ksu.exec` 单行返回 | 已适配 | 无 |

---

## 七、当前可用能力

```sh
# root 验证
python3 ~/tools/rootc.py 'id'
# → uid=0(root) gid=0(root) context=u:r:ksu:s0

# 身份
python3 ~/tools/rootc.py --info    # 显示 clone / userId 999 / uid 99910458
python3 ~/tools/rootc.py --role    # 只输出 clone

# 开关（只影响自己）
python3 ~/tools/rootc.py --off
python3 ~/tools/rootc.py --on

# 任意 root 命令
python3 ~/tools/rootc.py 'ls /data/adb/modules/'
```

**WebUI**：两个卡片独立开关，点击即生效。

---

## 八、文件清单

### 保留

| 文件 | 说明 |
|---|---|
| `v9.1-历史/rootd-module-v9.1.zip` | **最初安装的版本**（22170 B，用户手机原本的） |
| `v9.19-final/rootd-module-v9.19-final.zip` | **最新版本**（37932 B，本任务成果） |
| `README.md` | 项目说明 |
| `文档/` | 既有文档 |

### 删除

| 类别 | 内容 |
|---|---|
| 中间版本 | v9.3 ~ v9.14 共 12 个 zip |
| 临时文件 | index-new.html / rootc-new.py / rootd-priv-new.sh |
| 自检脚本 | check-rootd.sh + 说明（已过时） |
| 审查报告 | 审查-v9.3-multi/ 整个目录（已消化进本报告） |
| 历史目录 | v8.0-修改前/ / v9.2-最新/ / 回退-v8.0/ |

---

## 九、一句话总结

> 改造的核心难点不是「多实例」这个设计，而是三个环境陷阱：
> **`PATH` 缺失让守护静默失败**、**`ksu.exec` 只返回最后一行**、**三个启动入口抢同一个队列**。
> 这三个都靠真机日志和诊断面板发现，没有一个是我在沙箱里能测出来的。
