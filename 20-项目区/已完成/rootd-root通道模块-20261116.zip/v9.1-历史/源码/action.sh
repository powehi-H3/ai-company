#!/system/bin/sh
# action.sh —— KSU / Magisk 模块卡片上的「执行」按钮
#
# 用途：root 掉了（守护进程死了）时，点一下这个按钮就能原地恢复，
#       不用重启手机、不用开 Termux。
#
# v9.1 修复：
#   M1 存活判定改为「pid 活着 + 心跳新鲜」，pid 文件残留不再误判
#   M2 控制改用 setprop ctl.start/stop（init 原生），resetprop 仅兼容兜底
#   M7 off 权威标志迁到 $MODDIR/off + 私有目录
#   L7 删除 v8 的 token / 配对文案，路径与 install_client 对齐
export PATH=/data/adb/ksu/bin:/data/adb/magisk:/system/bin:/system/xbin:/vendor/bin:${PATH}

MODDIR=${0%/*}
CTL=/sdcard/rootd-out
PIDFILE="$CTL/rootd.pid"
HB="$CTL/heartbeat"
DAEMON="$MODDIR/common/rootd-priv.sh"

echo "============================================"
echo " rootd 一键恢复"
echo "============================================"

# M1：pid 活着 + 心跳新鲜（15s）才算在跑；只有 pid 文件不算
running() {
  P=$(cat "$PIDFILE" 2>/dev/null)
  [ -z "$P" ] && return 1
  kill -0 "$P" 2>/dev/null || return 1
  [ -f "$HB" ] || return 1
  T=$(date +%s); H=$(cat "$HB" 2>/dev/null)
  [ -z "$H" ] && return 1
  [ $((T - H)) -ge 15 ] && return 1
  return 0
}

# 解除关闭状态（三个位置都清）
clear_off() {
  rm -f "$MODDIR/off" "$CTL/off" 2>/dev/null
  for d in /data/user/*/*/files/runtime/rootfs/root/.dsh/rootd/off; do
    [ -e "$d" ] && rm -f "$d" 2>/dev/null
  done
  return 0
}

if running; then
  echo "守护已在运行 pid=$P"
  echo "（无需恢复）"
else
  echo "守护未运行，正在拉起..."
  # 清掉可能残留的 remove 标记（否则会被当作用户要卸载）
  rm -f "$MODDIR/remove" 2>/dev/null
  # 解除"关闭 root"开关
  clear_off
  echo "已解除关闭状态（off 标志已删除）"
  # M2：优先用 init 原生控制
  setprop ctl.start rootd-priv 2>/dev/null
  sleep 2
  # 兼容：属性触发（部分环境 resetprop 才生效）
  if ! running; then
    command -v resetprop >/dev/null 2>&1 && {
      resetprop rootd.ctl idle 2>/dev/null
      resetprop rootd.ctl start 2>/dev/null
    }
    sleep 2
  fi
  # 兜底：init 没起来就直接启动
  running || sh "$MODDIR/service.sh"
  sleep 2
  # 等待守护就绪（最多 20 秒，用心跳判定）
  i=0
  OK=0
  while [ $i -lt 20 ]; do
    sleep 1; i=$((i+1))
    if [ -f "$HB" ]; then
      T=$(date +%s); H=$(cat "$HB" 2>/dev/null)
      if [ -n "$H" ] && [ $((T - H)) -lt 5 ]; then OK=1; break; fi
    fi
  done
  P=$(cat "$PIDFILE" 2>/dev/null)
  if [ "$OK" = "1" ]; then
    echo "✅ 已恢复，守护 pid=$P"
  else
    echo "⚠️ 20 秒内未见心跳，守护可能未就绪"
    echo "   检查: cat $CTL/rootd.log"
    echo "   或重启手机（开机自动启动）"
  fi
fi

echo "--------------------------------------------"
if running; then
  echo "root 状态: 已开启（pid=$P，心跳 $(($(date +%s) - $(cat "$HB" 2>/dev/null || echo 0)))s 前）"
else
  echo "root 状态: 未运行"
fi
[ -e "$MODDIR/off" ] || [ -e "$CTL/off" ] && echo "  注意: off 标志存在（root 被主动关闭）"
echo "--------------------------------------------"
echo "在 dsh 里执行验证："
echo "  python3 \$HOME/tools/rootc.py 'id'"
echo "============================================"
