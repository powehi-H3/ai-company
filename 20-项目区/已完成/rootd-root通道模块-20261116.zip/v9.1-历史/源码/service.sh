#!/system/bin/sh
# service.sh —— 开机启动守护（真机 root 域）
#
# v9.1 修复：
#   S1 PIDFILE 与守护对齐（/sdcard/rootd-out/rootd.pid），不再读模块 state/
#   M1 存活判定统一为「pid 活着 + 心跳 15s 内」，与 action.sh / WebUI 一致
#   M1 oneshot 语义下 init 不会自动重启，本脚本兼作看门狗（被 service.d 周期调用）
export PATH=/data/adb/ksu/bin:/data/adb/magisk:/system/bin:/system/xbin:/vendor/bin:${PATH}

MODDIR=${0%/*}
STATE="$MODDIR/state"
LOG="$STATE/service.log"
mkdir -p "$STATE" 2>/dev/null

# 控制面（与守护一致）
CTL=/sdcard/rootd-out
PIDFILE="$CTL/rootd.pid"
HB="$CTL/heartbeat"
HB_STALE=15

log() { echo "$(date '+%F %T') $*" >>"$LOG" 2>/dev/null; }

log "service.sh start"

# 串行化：开机时 service.sh / boot-completed.sh / 99-rootd.sh 可能同时触发，
# 用 mkdir 原子锁保证只有一个真正执行（否则会启动多个守护实例）
LOCKDIR="$STATE/.svclock"
if ! mkdir "$LOCKDIR" 2>/dev/null; then
  log "another service.sh running, exit"
  exit 0
fi
trap 'rmdir "$LOCKDIR" 2>/dev/null' EXIT

# 关键：等 /sdcard 真正可用（开机早期可能还没挂载）
i=0
while [ ! -d /sdcard/Android ] && [ $i -lt 60 ]; do
  sleep 1; i=$((i+1))
done
log "sdcard ready after ${i}s"

# 启动诊断日志：写前先轮转，防止无限增长。
# 只保留最近 200 行（约 15KB），超过 64KB 就截断。
BOOTLOG=/sdcard/rootd-boot.log
if [ -f "$BOOTLOG" ] && [ "$(wc -c <"$BOOTLOG" 2>/dev/null || echo 0)" -gt 65536 ]; then
  tail -n 200 "$BOOTLOG" >"$BOOTLOG.tmp" 2>/dev/null && mv -f "$BOOTLOG.tmp" "$BOOTLOG" 2>/dev/null
fi
echo "$(date '+%F %T') service.sh ran, MODDIR=$MODDIR (sdcard waited ${i}s)" >> "$BOOTLOG" 2>/dev/null

mkdir -p "$CTL" 2>/dev/null

# M1：统一存活判定 —— pid 活着 + 心跳新鲜
alive() {
  P=$(cat "$PIDFILE" 2>/dev/null)
  [ -z "$P" ] && return 1
  kill -0 "$P" 2>/dev/null || return 1
  [ -f "$HB" ] || return 1
  T=$(date +%s); H=$(cat "$HB" 2>/dev/null)
  [ -z "$H" ] && return 1
  [ $((T - H)) -ge "$HB_STALE" ] && return 1
  return 0
}

# 用户主动关闭时不重启
if [ -e "$MODDIR/off" ] || [ -e "$CTL/off" ]; then
  log "off flag present, not starting"
  exit 0
fi

if alive; then
  log "daemon already running pid=$P (heartbeat ok)"
  exit 0
fi

# 有 pid 但心跳不新鲜 → 僵尸，杀掉
P=$(cat "$PIDFILE" 2>/dev/null)
if [ -n "$P" ] && kill -0 "$P" 2>/dev/null; then
  log "old pid=$P heartbeat stale, forcing restart"
  kill -9 "$P" 2>/dev/null
  sleep 1
fi
rm -f "$PIDFILE" 2>/dev/null

# 如果已通过 initrc 注册为 init 服务，优先让 init 启动
if [ -f "$MODDIR/initrc/rootd.rc" ]; then
  log "initrc present: asking init to start daemon"
  setprop ctl.start rootd-priv 2>/dev/null
  i=0
  while [ $i -lt 8 ]; do
    sleep 1; i=$((i+1))
    if alive; then
      log "init started daemon (hb fresh)"
      exit 0
    fi
  done
  log "init did not start daemon in 8s, fallback to self-start"
fi

DAEMON="$MODDIR/common/rootd-priv.sh"
[ -f "$DAEMON" ] || { log "FATAL: daemon missing"; exit 1; }

# 方式1：双重 fork 启动
( sh "$DAEMON" </dev/null >>"$CTL/rootd.log" 2>&1 & )
NEWPID=""
for t in 1 2 3 4 5 6 7 8 9 10 11 12 13 14 15; do
  sleep 1
  NEWPID=$(cat "$PIDFILE" 2>/dev/null)
  [ -n "$NEWPID" ] && kill -0 "$NEWPID" 2>/dev/null && break
  NEWPID=""
done

# 方式2：nohup 重试
if [ -z "$NEWPID" ]; then
  log "not detected yet, retry with nohup"
  nohup sh "$DAEMON" </dev/null >>"$CTL/rootd.log" 2>&1 &
  for t in 1 2 3 4 5 6 7 8; do
    sleep 1
    NEWPID=$(cat "$PIDFILE" 2>/dev/null)
    [ -n "$NEWPID" ] && kill -0 "$NEWPID" 2>/dev/null && break
    NEWPID=""
  done
fi

if [ -n "$NEWPID" ]; then
  log "daemon running pid=$NEWPID"
else
  log "WARN: daemon pid not confirmed after retries"
fi
exit 0
