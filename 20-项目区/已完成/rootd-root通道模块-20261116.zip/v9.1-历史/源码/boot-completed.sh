#!/system/bin/sh
# boot-completed.sh —— 系统完全启动后执行（KSU 支持）
# 兜底：确保守护在跑（此时 /sdcard 已完全就绪）
MODDIR=${0%/*}
STATE="$MODDIR/state"
mkdir -p "$STATE" 2>/dev/null

# 复用 service.sh 的启动逻辑
sh "$MODDIR/service.sh" >>"$STATE/boot.log" 2>&1
exit 0
