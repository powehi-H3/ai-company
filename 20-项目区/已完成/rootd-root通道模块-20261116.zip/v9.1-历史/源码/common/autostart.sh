#!/system/bin/sh
# autostart.sh —— 由 customize.sh 复制到 /data/adb/service.d/99-rootd.sh
# KSU/Magisk 会在 late_start 执行这里的所有脚本，从这里拉起的守护更能存活。
MODDIR=/data/adb/modules/rootd_keeper
echo "$(date '+%F %T') service.d launcher ran" >> /sdcard/rootd-boot.log 2>/dev/null
[ -d "$MODDIR" ] || exit 0
[ -e "$MODDIR/remove" ] && exit 0
[ -x "$MODDIR/service.sh" ] || exit 0
sh "$MODDIR/service.sh" </dev/null >/dev/null 2>&1
