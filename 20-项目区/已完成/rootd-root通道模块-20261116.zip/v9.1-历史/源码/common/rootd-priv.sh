#!/system/bin/sh
# rootd-priv.sh —— 真机 root 守护（v9.1 · 私有信箱 + 归属校验）
#
# v9.1 修复（对照 CodeBuddy 审查报告 S1-S4 / M1-M9 / L1-L9）：
#   S1 控制面路径分裂：LOG/PID/HEARTBEAT 固定 /sdcard/rootd-out（消费者一致），
#      只有 REQ/RES 命令通道走私有 700 目录
#   S2 客户端路径：BASE 统一为 ~/.dsh/rootd（去掉 v9test）；install_client 目标
#      改为 proot 真正的 /root/tools（= dirname(BASE)/tools）并 mkdir -p
#   S3 探测归属校验：probe_ok() 校验 rootfs/root/.dsh 布局 + app uid 范围 +
#      解析到的目标 uid 强一致，杜绝任意 App 劫持
#   S4 timeout -k 强制兜底；probe_deep 加超时 + -print -quit；心跳独立线程
#   M1 每个退出路径清理 pid + ctl.stop，避免僵尸 pid 跳过兜底
#   M2 控制改用 setprop ctl.start/stop（init 原生），属性触发作为兼容保留
#   M3 结果输出上限 MAX_OUT，超出截断
#   M5 install_client 只覆盖自家文件（ROOTD_MANAGED 标记）
#   M7 off 权威标志迁到私有目录 + MODDIR，/sdcard 的 off 只在通道未就绪时认
#   M8 seclabel 由 customize.sh 按环境生成（本文件不硬编码 KSU）
#   M9 探测覆盖 /data/user/*、/data/user_de/*，maxdepth 放宽到 12
#   L1 删除孤儿 sleep 看门狗（timeout -k 已覆盖），兜底分支改 KILL
#   L2 注释与实际频率对齐（sleep 2）
#   L3 /sdcard 日志同样轮转
#   L9 删除 v8 "# approved" 残留
#
# 关键事实（本机实测）：
#   proot 的 / 映射到 CE 区 /data/user/0/<pkg>/files/runtime/rootfs
#   CE 区开机未解锁时可能不可访问 → use_base() 循环等待，不退出
#   守护以 root 写回的文件必须 chown 回 app uid，否则 proot 内读不到
#   /sdcard 是 FUSE，chown 无效，控制面文件保持 root 属主即可
trap '' HUP TTOU TTIN

APP_HINT=io.github.ccch1mneyyy.dsh_app
MODDIR=/data/adb/modules/rootd_keeper

# ---------- 控制面（固定 /sdcard，所有消费者读这里）----------
CTL=/sdcard/rootd-out
LOGFALL="$CTL/rootd.log"
PIDFILE_FALL="$CTL/rootd.pid"
HB_FALL="$CTL/heartbeat"
OFF_FALL="$CTL/off"

TMO=120
MAX_AGE=300
LOG_MAX=1048576
MAX_RES_AGE=3600
# M3：单条结果 stdout/stderr 上限。
# 真机实测：mksh 的 printf 在参数超过约 100KB 时会静默失败（输出 0 字节）。
# base64 放大约 1.33 倍，所以原始数据必须留在 32KB 以内才能安全经过 printf。
# 用文件拼接（见 write_json）可绕开这个限制，但为了兼容性仍取保守值。
MAX_OUT=32768

mkdir -p "$CTL" 2>/dev/null
exec 2>>"$LOGFALL"
log() { echo "$(date '+%F %T') $*" >>"${LOG:-$LOGFALL}"; }
now() { date +%s 2>/dev/null; }

# ---------- 全局状态 ----------
BASE=""; REQ=""; RES=""; LOG=""; OWN=""; GRP=""
PIDFILE="$PIDFILE_FALL"; HEARTBEAT="$HB_FALL"
APP_UID=""
HBK=""
HB_STOP=0

# ---------- 退出清理（M1）----------
cleanup_exit() {
  HB_STOP=1
  [ -n "$HBK" ] && kill -KILL "$HBK" 2>/dev/null
  rm -f "$PIDFILE_FALL" "$PIDFILE" "$CTL/rootd.pid" 2>/dev/null
  # 通知 init 别再拉起（oneshot 下 init 不会重启，这里是双保险）
  setprop ctl.stop rootd-priv 2>/dev/null
}
trap 'cleanup_exit' EXIT

# ---------- 归属校验（S3 / M9）----------
# 从 pm / dumpsys 解析目标 App 的 uid；带 3s 超时，失败返回非 0。
# 解析成功后缓存，后续探测直接用。
resolve_app_uid() {
  [ -n "$APP_UID" ] && return 0
  u=""
  if command -v pm >/dev/null 2>&1; then
    u=$(timeout 3 pm list packages -U 2>/dev/null \
        | grep "^package:$APP_HINT " \
        | sed -n 's/.*uid:\([0-9][0-9]*\).*/\1/p' | head -n1)
  fi
  if [ -z "$u" ] && command -v dumpsys >/dev/null 2>&1; then
    u=$(timeout 3 dumpsys package "$APP_HINT" 2>/dev/null \
        | sed -n 's/^ *userId=\([0-9][0-9]*\).*/\1/p' | head -n1)
  fi
  [ -z "$u" ] && return 1
  APP_UID="$u"
  log "resolved app uid=$APP_UID"
  return 0
}

# 校验候选目录确实是目标 dsh 的私有 rootfs。
# 判据（全部满足才通过）：
#   1) 布局必须是 <...>/rootfs/root/.dsh
#   2) 目录属主必须是 app uid（>=10000，排除 root/system）
#   3) 若能解析出目标 uid，必须严格相等
#   4) 若存在 .rootd_owner 标记，其内容必须是 APP_HINT 或目标 uid
probe_ok() {
  c="$1"
  [ -d "$c" ] || return 1
  # 1) 布局校验：父=root，祖父=rootfs
  [ "$(basename "$(dirname "$c")")" = "root" ] || return 1
  [ "$(basename "$(dirname "$(dirname "$c")")")" = "rootfs" ] || return 1
  # 2) 属主必须是 app uid
  u=$(stat -c %u "$c" 2>/dev/null)
  [ -z "$u" ] && return 1
  [ "$u" -ge 10000 ] 2>/dev/null || return 1
  # 3) 已知目标 uid 时强校验
  if resolve_app_uid; then
    [ "$u" = "$APP_UID" ] || { log "probe reject $c (uid=$u want=$APP_UID)"; return 1; }
  fi
  # 4) 归属标记（存在则必须匹配）
  if [ -f "$c/.rootd_owner" ]; then
    m=$(head -c 128 "$c/.rootd_owner" 2>/dev/null | tr -d ' \n')
    if [ -n "$m" ] && [ "$m" != "$APP_HINT" ] && [ "$m" != "$u" ]; then
      log "probe reject $c (marker=$m)"; return 1
    fi
  fi
  printf '%s' "$c"
  return 0
}

# ---------- 三级路径探测（M9：覆盖多用户 / DE 区）----------
# 频率：exact 每 2s、glob 每 20s、deep 每 300s（主循环 sleep 2，i 每轮 +1）

# 1) 精确包名（开销小，每轮试）
probe_exact() {
  for c in \
    /data/user/*/"$APP_HINT"/files/runtime/rootfs/root/.dsh \
    /data/user_de/*/"$APP_HINT"/files/runtime/rootfs/root/.dsh \
    /proc/1/root/data/user/*/"$APP_HINT"/files/runtime/rootfs/root/.dsh; do
    [ -d "$c" ] || continue
    r=$(probe_ok "$c") && { printf '%s' "$r"; return 0; }
  done
  return 1
}

# 2) 通配（每 20s 试，包名不同但布局相同）
probe_glob() {
  for c in \
    /data/user/*/*/files/runtime/rootfs/root/.dsh \
    /data/user_de/*/*/files/runtime/rootfs/root/.dsh \
    /proc/1/root/data/user/*/*/files/runtime/rootfs/root/.dsh; do
    [ -d "$c" ] || continue
    r=$(probe_ok "$c") && { printf '%s' "$r"; return 0; }
  done
  return 1
}

# 3) 深度探测（每 300s，布局变了也能找；S4：加超时 + -print -quit）
probe_deep() {
  d=$(timeout 20 find /data/user /data/user_de -maxdepth 12 \
        -type d -name .dsh -print -quit 2>/dev/null)
  [ -n "$d" ] || return 1
  r=$(probe_ok "$d") && { printf '%s' "$r"; return 0; }
  return 1
}

use_base() {
  BASE="$1"
  # S1：命令通道走私有 700，控制面留在 /sdcard
  REQ="$BASE/rootd/req"
  RES="$BASE/rootd/res"
  LOG="$CTL/rootd.log"
  PIDFILE="$CTL/rootd.pid"
  HEARTBEAT="$CTL/heartbeat"
  OWN=$(stat -c %u "$BASE" 2>/dev/null)
  GRP=$(stat -c %g "$BASE" 2>/dev/null)
  # M5：不猜 uid，stat 失败就放弃这一轮（下一轮重探）
  if [ -z "$OWN" ]; then
    log "WARN: stat failed for $BASE, skip"
    return 1
  fi
  [ -z "$GRP" ] && GRP=$OWN
  mkdir -p "$REQ" "$RES" 2>/dev/null || return 1
  chown -R "$OWN:$GRP" "$BASE/rootd" 2>/dev/null
  chmod 700 "$BASE/rootd" "$REQ" "$RES" 2>/dev/null
  # 清理残留
  rm -f "$REQ"/.run-* 2>/dev/null
  find "$RES" -maxdepth 1 -name '*.out' -mmin +$((MAX_RES_AGE/60)) -delete 2>/dev/null
  find "$REQ" -maxdepth 1 -name '*.sh' -mmin +$((MAX_AGE/60)) -delete 2>/dev/null
  # 自动安装/更新客户端到 proot 的 /root/tools
  install_client
  return 0
}

# ---------- 自动安装客户端（S2 / M5）----------
CLIENT_SRC="$MODDIR/client/rootc.py"
CLIENT_MARK="ROOTD_MANAGED"

install_client() {
  [ -f "$CLIENT_SRC" ] || return 0
  # S2：proot 的 /root 就是 $BASE 的父目录（.../rootfs/root/.dsh → .../rootfs/root）
  R="$(dirname "$BASE")/tools"
  mkdir -p "$R" 2>/dev/null || { log "WARN: mkdir $R failed"; return 0; }
  T="$R/rootc.py"
  # 已存在且内容相同就跳过（避免每次重启都写）
  if [ -f "$T" ] && cmp -s "$CLIENT_SRC" "$T" 2>/dev/null; then
    return 0
  fi
  # M5：目标已存在但不是自家文件（无标记）→ 不动用户的
  if [ -f "$T" ] && ! grep -q "$CLIENT_MARK" "$T" 2>/dev/null; then
    log "skip client install: $T is user-owned (no $CLIENT_MARK)"
    return 0
  fi
  cp -f "$CLIENT_SRC" "$T.new" 2>/dev/null || return 0
  chown "$OWN:$GRP" "$T.new" 2>/dev/null
  chmod 755 "$T.new" 2>/dev/null
  mv -f "$T.new" "$T" 2>/dev/null
  chown "$OWN:$GRP" "$T" 2>/dev/null
  rm -f "$T.new" 2>/dev/null
  log "client installed: $T (owner=$OWN:$GRP)"
  return 0
}

# 私有通道文件才 chown；/sdcard 是 FUSE，chown 无效也不必要
chown_res() {
  case "$1" in
    "$CTL"/*) chmod 644 "$1" 2>/dev/null ;;
    *) [ -n "$OWN" ] && chown "$OWN:$GRP" "$1" 2>/dev/null
       chmod 600 "$1" 2>/dev/null ;;
  esac
}

# ---------- 等待通道就绪（CE 区开机未解锁时循环等，不退出）----------
wait_base() {
  i=0
  while true; do
    # M7：通道未就绪时仍认 /sdcard 的 off（WebUI 可用），就绪后只认私有
    if [ -e "$OFF_FALL" ] || [ -e "$MODDIR/off" ]; then
      log "off flag during wait: shutting down"; exit 0
    fi
    b=$(probe_exact)
    [ -z "$b" ] && [ $((i % 10)) -eq 0 ] && b=$(probe_glob)
    [ -z "$b" ] && [ $((i % 150)) -eq 0 ] && [ "$i" -gt 0 ] && b=$(probe_deep)
    if [ -n "$b" ] && use_base "$b"; then
      log "channel ready: $BASE (owner=$OWN:$GRP)"
      return 0
    fi
    i=$((i+1))
    [ $((i % 30)) -eq 0 ] && log "waiting for app private channel (${i} rounds, CE may be locked)"
    sleep 2
  done
}

# ---------- 实例登记 ----------
OPID=""
[ -f "$PIDFILE_FALL" ] && OPID=$(cat "$PIDFILE_FALL" 2>/dev/null)
if [ -n "$OPID" ] && [ "$OPID" != "$$" ] && kill -0 "$OPID" 2>/dev/null; then
  log "takeover: killing old instance $OPID"
  kill -9 "$OPID" 2>/dev/null
  sleep 0.5
fi
echo "$$" > "$PIDFILE_FALL" 2>/dev/null
now > "$HB_FALL" 2>/dev/null

wait_base
echo "$$" > "$PIDFILE" 2>/dev/null
now > "$HEARTBEAT" 2>/dev/null
log "started pid=$$ (private mailbox, NO token)"

# ---------- S4：心跳独立线程，不被长命令阻塞 ----------
( while :; do
    [ "$HB_STOP" = "1" ] && exit 0
    now > "$HEARTBEAT" 2>/dev/null
    sleep 2
  done ) &
HBK=$!

write_res() {
  # $1=base $2=exit $3=stdout(base64) $4=stderr(base64)  → 写 .out
  write_json "$RES/.$1.tmp" "$2" "$3" "$4"
  mv -f "$RES/.$1.tmp" "$RES/$1.out" 2>/dev/null
  chown_res "$RES/$1.out"
}

# 用文件拼接写 JSON，避开 mksh printf 在 ~100KB 参数上的静默失败。
# $1=输出文件 $2=exit $3=stdout(b64) $4=stderr(b64)
write_json() {
  f="$1"
  {
    printf '{"exit":%d,"stdout":"' "$2"
    printf '%s' "$3"
    printf '","stderr":"'
    printf '%s' "$4"
    printf '"}'
  } >"$f" 2>/dev/null || : >"$f"
}

# M3：截断超大输出，避免撑爆 /data 与内存
cap_file() {
  f="$1"
  sz=$(wc -c <"$f" 2>/dev/null || echo 0)
  [ "$sz" -gt "$MAX_OUT" ] 2>/dev/null || return 0
  head -c "$MAX_OUT" "$f" >"$f.cap" 2>/dev/null && mv -f "$f.cap" "$f" 2>/dev/null
  echo "" >>"$f" 2>/dev/null
  echo "[rootd] output truncated at ${MAX_OUT}B (original ${sz}B)" >>"$f" 2>/dev/null
}

run_cmd() {
  cmd="$1"; base="$2"
  o="$RES/.$base.o"; e="$RES/.$base.e"
  : >"$o"; : >"$e"
  if command -v timeout >/dev/null 2>&1; then
    # S4：-k 强制 KILL，防子进程忽略 TERM 导致永久卡死
    timeout -k 5 "$TMO" /system/bin/sh -c "$cmd" >"$o" 2>"$e"; ec=$?
  else
    # 兜底：无 timeout 时手工看门狗（直接 KILL，不等待）
    /system/bin/sh -c "$cmd" >"$o" 2>"$e" & p=$!
    ( sleep "$TMO"; kill -KILL "$p" 2>/dev/null ) >/dev/null 2>&1 & w=$!
    wait "$p"; ec=$?; kill -KILL "$w" 2>/dev/null
  fi
  # 124=timeout, 137=KILL, 143=TERM
  if [ "$ec" = "124" ] || [ "$ec" = "137" ] || [ "$ec" = "143" ]; then
    ec=124
    echo "[rootd] command timeout after ${TMO}s" >>"$e" 2>/dev/null
  fi
  cap_file "$o"
  cap_file "$e"
  ob=$(base64 "$o" 2>/dev/null | tr -d '\n')
  eb=$(base64 "$e" 2>/dev/null | tr -d '\n')
  write_json "$RES/.$base.tmp" "$ec" "$ob" "$eb"
  mv -f "$RES/.$base.tmp" "$RES/$base.out" 2>/dev/null
  chown_res "$RES/$base.out"
  rm -f "$o" "$e" 2>/dev/null
}

housekeeping() {
  # L3：私有日志和 /sdcard 日志都轮转
  for f in "$LOG" "$LOGFALL"; do
    [ -f "$f" ] || continue
    [ "$(wc -c <"$f" 2>/dev/null || echo 0)" -gt "$LOG_MAX" ] || continue
    tail -n 400 "$f" >"$f.tmp" 2>/dev/null && mv -f "$f.tmp" "$f" 2>/dev/null
  done
  find "$RES" -maxdepth 1 \( -name '*.out' -o -name '.*.o' -o -name '.*.e' \) -mmin +$((MAX_RES_AGE/60)) -delete 2>/dev/null
  find "$REQ" -maxdepth 1 -name '.lock_*' -mmin +$((MAX_RES_AGE/60)) -exec rmdir {} \; 2>/dev/null
  find "$REQ" -maxdepth 1 -name '*.sh' -mmin +$((MAX_AGE/60)) -delete 2>/dev/null
}

hk=0
while true; do

  # 守护若被系统以别的 uid 起、或 BASE 消失，重新探测
  if [ ! -d "$BASE" ]; then
    log "channel lost, re-probing"
    wait_base
    echo "$$" > "$PIDFILE" 2>/dev/null
  fi

  # 自毁
  if [ ! -d "$MODDIR" ]; then
    log "self-destruct: module dir gone"
    rm -rf "$BASE/rootd" /sdcard/rootd-in 2>/dev/null
    exit 0
  fi
  if [ -e "$MODDIR/remove" ]; then
    log "self-destruct: remove flag"
    rm -rf "$BASE/rootd" /sdcard/rootd-in 2>/dev/null
    exit 0
  fi
  if [ -e "$MODDIR/disable" ]; then
    log "disable flag, exit (keep data)"; exit 0
  fi
  # M7：off 权威标志在私有目录 / MODDIR；/sdcard 的 off 仅作兼容兜底
  if [ -e "$BASE/rootd/off" ] || [ -e "$MODDIR/off" ]; then
    log "off flag: shutting down (root revoked)"; exit 0
  fi

  hk=$((hk+1)); [ $((hk % 30)) -eq 0 ] && housekeeping

  mkdir -p "$REQ" "$RES" 2>/dev/null
  NOW=$(now)
  for f in "$REQ"/*.sh; do
    [ -e "$f" ] || continue
    base="$(basename "$f" .sh)"

    mt=$(stat -c %Y "$f" 2>/dev/null)
    if [ -n "$mt" ] && [ -n "$NOW" ] && [ $((NOW - mt)) -gt "$MAX_AGE" ]; then
      write_res "$base" 125 "" "cmVxdWVzdCBzdGFsZSAoZXhwaXJlZCk="
      rm -f "$f" 2>/dev/null; log "stale $base (age=$((NOW - mt))s)"; continue
    fi

    RUN="$REQ/.run-$base.sh"
    mv -f "$f" "$RUN" 2>/dev/null || continue
    cmd=$(cat "$RUN" 2>/dev/null)
    rm -f "$RUN" 2>/dev/null
    [ -z "$cmd" ] && continue
    log "run $base: $(printf '%s' "$cmd" | head -c 200 | tr '\n' ' ')"
    run_cmd "$cmd" "$base"
    log "ok $base"
  done
  sleep 2
done
