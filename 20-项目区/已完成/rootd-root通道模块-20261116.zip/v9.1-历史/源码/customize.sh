#!/system/bin/sh
# customize.sh —— 被安装器 source（不是执行）
SKIPUNZIP=0

ui_print "********************************************"
ui_print " rootd 真机 root 通道（dsh 专用版 v9.1）"
ui_print "********************************************"
ui_print " "
ui_print "- 命令队列在 dsh 私有目录（700，其他 App 读不到）"
ui_print "- 无需 token：靠目录权限隔离"
ui_print "- 客户端开机自动安装到 proot 的 /root/tools"
ui_print "- 守护由 init 托管，卸载后自毁；重启彻底消失"
ui_print " "

if [ ! -d /data/adb ]; then
  ui_print "! /data/adb 不存在：本机可能不是 KernelSU/Magisk/APatch"
  abort "! 安装中止"
fi

# M8：按环境生成 seclabel（KSU=ksu:s0 / Magisk=magisk:s0）
if [ -f "$MODPATH/initrc/rootd.rc" ]; then
  if command -v ksud >/dev/null 2>&1 || [ -d /data/adb/ksu ]; then
    SEC="u:r:ksu:s0"; ENVNAME="KernelSU"
  elif [ -d /data/adb/magisk ]; then
    SEC="u:r:magisk:s0"; ENVNAME="Magisk"
  else
    SEC="u:r:su:s0"; ENVNAME="unknown"
  fi
  sed -i "s|seclabel u:r:ksu:s0|seclabel $SEC|" "$MODPATH/initrc/rootd.rc" 2>/dev/null
  ui_print "- 环境: $ENVNAME，seclabel 设为 $SEC"
fi

# 设置脚本权限
for f in service.sh post-fs-data.sh boot-completed.sh uninstall.sh action.sh common/rootd-priv.sh; do
  [ -f "$MODPATH/$f" ] && set_perm "$MODPATH/$f" 0 0 0755
done
# 客户端也要可执行
[ -f "$MODPATH/client/rootc.py" ] && set_perm "$MODPATH/client/rootc.py" 0 0 0755

ui_print "- 安装完成"
ui_print "- 重启手机后守护由 init 启动"
ui_print "- 或立即启用：su -c 'sh /data/adb/modules/rootd_keeper/service.sh'"

# 把开机启动器放到 service.d（KSU/Magisk 保证会执行这里）
if [ -f "$MODPATH/common/autostart.sh" ]; then
  mkdir -p /data/adb/service.d 2>/dev/null
  cp -f "$MODPATH/common/autostart.sh" /data/adb/service.d/99-rootd.sh 2>/dev/null
  chmod 755 /data/adb/service.d/99-rootd.sh 2>/dev/null
  ui_print "- 已安装开机启动器: /data/adb/service.d/99-rootd.sh"
fi

# 清掉残留的 remove/disable 标记（否则 KSU 会跳过本模块）
# 注意：既要清新目录($MODPATH)，也要清旧安装目录，否则旧标记会让 KSU 跳过整个模块
rm -f "$MODPATH/remove" "$MODPATH/disable" 2>/dev/null
rm -f /data/adb/modules/rootd_keeper/remove /data/adb/modules/rootd_keeper/disable 2>/dev/null
ui_print "- 已清除 remove/disable 标记（新旧两处）"
