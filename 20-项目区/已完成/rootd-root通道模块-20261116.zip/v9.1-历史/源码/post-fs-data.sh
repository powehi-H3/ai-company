#!/system/bin/sh
# post-fs-data.sh —— BLOCKING 阶段（要极快，不能做重活）
# 只做一件事：确保模块内 bin/ 目录存在。
# 守护的启动全部交给 service.sh，不往 /data/adb/service.d/ 投放脚本。

MODDIR=${0%/*}
mkdir -p "$MODDIR/bin" 2>/dev/null
exit 0
