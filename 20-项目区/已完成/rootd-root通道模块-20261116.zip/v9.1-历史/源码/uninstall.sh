#!/system/bin/sh
# uninstall.sh —— 模块卸载时执行（真机 root 域）
#
# 关键原则：
#   1. 清理顺序：先停进程 → 再删数据 → 最后删自己相关
#   2. 不能在中途删掉自己导致后续步骤跳过
#   3. 设 remove 标记，重启后由管理器彻底删除模块目录

MODDIR=${0%/*}
log() { echo "[uninstall] $*"; }

# ---------- 1) 让守护优雅退出 ----------
# 关键：先设 remove 标记，守护下一轮循环会自己 exit（它会写一条日志，所以之后再清）
# 直接 kill 也行，但那样守护没机会收尾；先礼后兵更稳。
log "step 1: stop daemons"
touch "$MODDIR/remove" 2>/dev/null && log "  remove flag set (graceful)"
sleep 2

# 兜底：还在跑就直接杀
for p in $(ps -A 2>/dev/null | grep -E "sh .*/rootd\.sh|sh .*/rootd-priv\.sh|sh .*/rootd-mini\.sh" | awk '{print $2}'); do
  [ "$p" = "$$" ] && continue
  kill -KILL "$p" 2>/dev/null && log "  force killed $p"
done
[ -f /sdcard/rootd-out/rootd.pid ] && {
  P=$(cat /sdcard/rootd-out/rootd.pid 2>/dev/null)
  [ -n "$P" ] && kill -KILL "$P" 2>/dev/null && log "  force killed pid=$P"
}
sleep 1

# ---------- 2) 删 /sdcard 通道数据 ----------
# 关键：守护自毁时会写日志重建目录，所以要"删→等→再删"反复几次
log "step 2: remove /sdcard channel"
clean_channel() {
  for d in /sdcard/rootd-in /sdcard/rootd-out; do
    [ -e "$d" ] || continue
    rm -rf "$d" 2>/dev/null
    [ -e "$d" ] && { find "$d" -mindepth 1 -delete 2>/dev/null; rmdir "$d" 2>/dev/null; }
    rm -rf "$d" 2>/dev/null
  done
}
# 先删一次
clean_channel
# 等守护察觉到模块要没了、自己退出（它可能还在写日志）
sleep 2
# 再删一次，清掉自毁期间重建的内容
clean_channel
sleep 1
clean_channel
for d in /sdcard/rootd-in /sdcard/rootd-out; do
  [ -e "$d" ] && log "  WARN still exists: $d" || log "  removed $d"
done

# ---------- 3) 删 /sdcard 其他残留 ----------
log "step 3: remove other /sdcard artifacts"
for f in /sdcard/rootd.sh /sdcard/rootd-mini.sh /sdcard/rootd-cleanup.sh \
         /sdcard/proot_probe.txt /sdcard/.rootd-token /sdcard/rootd-install.sh \
         /sdcard/rootd-boot.log /sdcard/rootd-priv-new.sh /sdcard/fix-rootd.sh \
         /sdcard/service-new.sh /sdcard/service-v47.sh /sdcard/deploy.sh \
         /sdcard/deploy2.sh /sdcard/diag.sh /sdcard/check2.sh /sdcard/check3.sh \
         /sdcard/verify.sh /sdcard/teststart.sh /sdcard/test2.sh /sdcard/test3.sh; do
  [ -e "$f" ] && rm -f "$f" 2>/dev/null && log "  removed $f"
done
for d in /sdcard/root-requests /sdcard/root-results /sdcard/rq2 /sdcard/rs2; do
  if [ -e "$d" ]; then
    rm -rf "$d" 2>/dev/null
    [ -e "$d" ] && { find "$d" -mindepth 1 -delete 2>/dev/null; rmdir "$d" 2>/dev/null; }
    [ -e "$d" ] || log "  removed $d"
  fi
done

# ---------- 4) 删 service.d 遗留（旧版本可能放过）----------
log "step 4: remove service.d leftovers"
for f in /data/adb/service.d/rootd*.sh /data/adb/service.d/99-rootd.sh; do
  [ -e "$f" ] && rm -f "$f" 2>/dev/null && log "  removed $f"
done

# ---------- 5) 删 dsh 私有目录通道（v8 旧布局 + v9 rootfs 布局）----------
# M6：v9 的信箱在 files/runtime/rootfs/root/.dsh/rootd，v8 的 files/rootd 通配匹配不到，
#     必须显式覆盖；自动安装的客户端 ~/tools/rootc.py 也要删。
log "step 5: remove private channel"
setprop ctl.stop rootd-priv 2>/dev/null
setprop rootd.ctl "" 2>/dev/null
for base in /data/user /data/user_de /data/data; do
  [ -d "$base" ] || continue
  for d in \
    "$base"/*/*/files/rootd \
    "$base"/*/*/files/runtime/rootfs/root/.dsh/rootd \
    "$base"/*/*/files/runtime/rootfs/root/.dsh/v9test \
    "$base"/*/*/files/runtime/rootfs/root/.dsh/tools \
    "$base"/*/files/rootd ; do
    [ -d "$d" ] || continue
    rm -rf "$d" 2>/dev/null && log "  removed $d"
  done
  # 自动安装的客户端（只删带 ROOTD_MANAGED 标记的，保留用户自建）
  for f in \
    "$base"/*/*/files/runtime/rootfs/root/tools/rootc.py \
    "$base"/*/files/runtime/rootfs/root/tools/rootc.py ; do
    [ -f "$f" ] || continue
    grep -q 'ROOTD_MANAGED' "$f" 2>/dev/null || continue
    rm -f "$f" 2>/dev/null && log "  removed $f"
  done
done

# ---------- 6) 删模块内运行状态 ----------
log "step 6: remove module state"
rm -rf "$MODDIR/state" 2>/dev/null && log "  removed state/"
rm -rf "$MODDIR/bin" 2>/dev/null && log "  removed bin/"
rm -f "$MODDIR/off" 2>/dev/null

# ---------- 7) 确认 remove 标记（第1步已设，这里确保在位）----------
log "step 7: verify remove flag"
if [ -e "$MODDIR/remove" ]; then
  log "  remove flag present"
else
  touch "$MODDIR/remove" 2>/dev/null && log "  remove flag set"
fi

log "done — 重启后模块目录与所有残留彻底消失"
exit 0
