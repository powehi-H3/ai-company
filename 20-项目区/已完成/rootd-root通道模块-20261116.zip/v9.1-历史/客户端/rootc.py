#!/usr/bin/env python3
# ROOTD_MANAGED —— 本文件由 rootd 模块守护自动安装/更新。
# 删除这一行会让守护认为它是用户自有文件，从而不再覆盖。
#
# rootc.py —— 真机 root 通道客户端（v9.1）
#
# 通道：~/.dsh/rootd/{req,res}
#   与真机侧 CE 目录 /data/user/0/<pkg>/files/runtime/rootfs/root/.dsh/rootd
#   是同一 inode，守护以 root 读写，这里以 app uid 读写。
#
# 用法：
#   rootc.py 'id'
#   rootc.py 'ls -la /data/adb/modules'
#   rootc.py ls -la /data/adb/modules          # 多参数会自动拼接
#   ROOTC_TIMEOUT=300 rootc.py 'sleep 200'     # 自定义超时（秒）
#
# 退出码：命令自身的退出码；125=请求过期；124=超时；126=通道不可用

import base64
import json
import os
import sys
import time
import uuid

HOME = os.path.expanduser("~")
BASE = os.path.join(HOME, ".dsh", "rootd")
REQ = os.path.join(BASE, "req")
RES = os.path.join(BASE, "res")
OFF = os.path.join(BASE, "off")

# 守护默认 TMO=120，客户端留 10s 余量，避免「假超时」
DEFAULT_TIMEOUT = int(os.environ.get("ROOTC_TIMEOUT", "130"))


def b64d(s):
    if not s:
        return b""
    s = s.strip()
    pad = (-len(s)) % 4
    if pad:
        s += "=" * pad
    try:
        return base64.b64decode(s)
    except Exception:
        return b""


def die(msg, code=126):
    sys.stderr.write("rootc: %s\n" % msg)
    sys.exit(code)


def run_once(cmdtxt, timeout=DEFAULT_TIMEOUT):
    if not os.path.isdir(REQ):
        die("channel not ready: %s missing (module not installed or daemon not up)" % REQ)

    if os.path.exists(OFF):
        die("root revoked: %s exists. Re-enable via module WebUI / action.sh" % OFF)

    rid = uuid.uuid4().hex
    req = os.path.join(REQ, rid + ".sh")
    res = os.path.join(RES, rid + ".out")

    # 原子落盘：先写临时文件再 rename，守护不会读到半截
    tmp = req + ".tmp"
    try:
        with open(tmp, "w", encoding="utf-8") as f:
            f.write(cmdtxt)
        os.replace(tmp, req)
    except Exception as e:
        die("cannot submit request: %s" % e)

    deadline = time.time() + timeout
    while time.time() < deadline:
        if os.path.exists(res):
            try:
                # 上限 1MB，防止超大结果撑爆内存
                raw = open(res, "rb").read(1 << 20)
            except Exception:
                time.sleep(0.05)
                continue
            if not raw.endswith(b"}"):
                time.sleep(0.05)   # 半写，等下一轮
                continue
            try:
                j = json.loads(raw.decode("utf-8", "replace"))
            except Exception:
                time.sleep(0.05)
                continue
            if "exit" not in j:
                time.sleep(0.05)
                continue
            try:
                os.unlink(res)
            except Exception:
                pass
            return int(j.get("exit", 1)), b64d(j.get("stdout", "")), b64d(j.get("stderr", ""))
        time.sleep(0.05)

    # 超时：尽力撤回请求（守护可能已取走，删不到也无妨）
    try:
        os.unlink(req)
    except Exception:
        pass
    return 124, b"", b"timeout waiting for rootd"


def main():
    if len(sys.argv) < 2:
        sys.stderr.write(
            "usage: rootc.py <command...>\n"
            "       ROOTC_TIMEOUT=300 rootc.py 'long command'\n"
        )
        sys.exit(2)

    # 支持多参数：rootc.py ls -la /data/adb → "ls -la /data/adb"
    cmdtxt = " ".join(sys.argv[1:])
    code, out, err = run_once(cmdtxt)
    try:
        sys.stdout.buffer.write(out)
        sys.stdout.buffer.flush()
    except Exception:
        pass
    try:
        sys.stderr.buffer.write(err)
        sys.stderr.buffer.flush()
    except Exception:
        pass
    sys.exit(code)


if __name__ == "__main__":
    main()
