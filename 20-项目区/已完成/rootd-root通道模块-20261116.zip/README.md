# AI 获取真机 root 权限模块

> 最后整理：2026-11-14 14:22
> **保留三版：v8.0（修改前）+ v9.1（历史）+ v9.2（最新，安全修复版）**

---

## 目录

```
AI获取root权限模块/
├── v8.0-修改前/          ← 真机当前运行的版本
│   ├── rootd-module-v8.0.zip     可刷包（15K）
│   ├── 源码/                      完整源码
│   └── 客户端/rootc.py            proot 侧客户端
│
├── v9.1-最新/            ← 修完 22 项缺陷，待刷
│   ├── rootd-module-v9.1.zip     可刷包（22K，md5 9bb4bb77）
│   ├── 源码/
│   ├── 客户端/rootc.py
│   └── 修复报告-v9.1.md          22 项修复明细 + 验证结果
│
├── 回退-v8.0/            ← 刷 v9.1 出问题时的退路
│   ├── rootd-rollback.sh         一键回退
│   ├── rootd-priv-v8.0.sh        v8.0 守护
│   └── rootc-v8.py               v8.0 客户端
│
└── 文档/
    ├── README.md                  本文件
    └── 轮子评估报告.md            社区同类方案对比
```

---

## 当前状态

| 项目 | 值 |
|---|---|
| 真机运行版本 | **v9.2**（versionCode=92）✅ 已刷入并验证 |
| root 通道 | 正常（uid=0, u:r:ksu:s0） |
| init 托管 | `init.svc.rootd-priv=running`，ppid=1 |
| 守护 pid | 10167（重启后自动变） |
| 信箱 | `~/.dsh/rootd/` (700) |
| 权威状态 | `/data/adb/modules/rootd_keeper/state/` (700 root) |

---

## 两版差异

| | v8.0 | v9.1 |
|---|---|---|
| 通信通道 | `/sdcard/rootd-in` + `rootd-out` | 私有目录 700（其他 App 读不到） |
| 鉴权 | token（生成/配对/轮换） | 无需 token，靠目录权限隔离 |
| 路径 | 写死 | 三级探测（精确/通配/深度）+ uid 归属校验 |
| 客户端安装 | 手动拷到 `/root/tools` | 守护开机自动装 |
| 超时 | `timeout` 无 `-k`（可被永久卡死） | `timeout -k 5` 强制杀 |
| 输出上限 | 无（可撑爆 /data） | 256KB 截断 |
| init 语义 | 未声明 oneshot（可能重启风暴） | `oneshot`，退出即停 |

**v9.0 已删除** —— 有 4 个严重缺陷（心跳冻结 / 路径不通 / 探测可劫持 / 永久卡死），刷了不通。v9.1 是在它基础上修完 22 项后的版本。

---

## 已刷入（2026-11-14 10:41）

真机已是 v9.1，全部验证通过：

| 项目 | 结果 |
|---|---|
| root 通道 | ✅ uid=0, u:r:ksu:s0 |
| init 托管 | ✅ init.svc.rootd-priv=running, ppid=1 |
| 输出限长 | ✅ 1MB → 32824B（含截断提示） |
| 长命令 | ✅ sleep 65 → 67s，无假超时 |
| 超时强杀 | ✅ trap '' TERM → 126s 被杀，通道存活 |
| 退出码/stderr | ✅ 正确传递 |
| WebUI 开启按钮 | ✅ `rootd.ctl=start`（按钮写入的属性） |
| WebUI 取消按钮 | ✅ `off` 标志曾生效，之后被清除 |

**如需重刷**：

1. KernelSU → 模块 → 从本地安装 → 选 `v9.1-最新/rootd-module-v9.1.zip`
2. 重启手机
3. 等 30 秒

验证：
```sh
python3 $HOME/tools/rootc.py 'id'
# 期望：uid=0(root) gid=0(root) context=u:r:ksu:s0
```

**注意 zip 结构**：`module.prop` 必须在 zip 根目录。如果刷入失败提示找不到 module.prop，说明 zip 多套了一层目录。

---

## 回退

```sh
su -c 'sh /sdcard/rootd-rollback.sh'
```

会同时回退守护和客户端到 v8.0。

---

## 验证方法（比看日志可靠）

日志在守护重启时会被截断，**不能只靠 `rootd.log` 判断操作是否生效**。用这几个状态位更准：

```sh
# 1. 服务是否由 init 托管
getprop init.svc.rootd-priv        # 期望: running

# 2. WebUI「开启」按钮是否被点过（会写这个属性）
getprop rootd.ctl                  # 期望: start

# 3. 是否被「取消 root」
ls /data/adb/modules/rootd_keeper/off        # 有 = 已取消
ls /sdcard/rootd-out/off                      # 兼容位置

# 4. 守护是否活着（pid + 心跳新鲜度）
cat /sdcard/rootd-out/rootd.pid
cat /sdcard/rootd-out/heartbeat    # 和 date +%s 差 < 15 才算活

# 5. 通道本身
python3 $HOME/tools/rootc.py 'id'  # 期望: uid=0(root) ... u:r:ksu:s0
```

---

## 已知问题与修复记录

### Bug 1：大输出返回空（已修）

**现象**：`yes`、`find /` 这类大输出命令返回 0 字节。

**原因**：mksh 的 `printf` 在参数超过约 100KB 时静默失败。实测阈值：65536 正常 / 131072 失败。

**修复**：`MAX_OUT` 从 262144 降到 32768；JSON 写入从单个 `printf` 改成文件拼接（`write_json`），彻底绕开长度限制。

### v9.2 安全修复（2026-11-14 14:20）

排查发现 3 个问题，全部已修并在真机验证：

**高危：pid 文件可被伪造，导致任意进程被杀**

`/sdcard/rootd-out/rootd.pid` 所有 App 可写。守护启动时读它并 `kill -9`：

```sh
OPID=$(cat "$PIDFILE_FALL")     # 读 /sdcard 的 pid
kill -9 "$OPID"                  # 杀任何写进来的 pid
```

恶意 App 写个目标进程的 pid 进去，守护重启时就会杀掉它。

**修复**：权威 pid 迁到 `/data/adb/modules/rootd_keeper/state/`（700 root），
且 kill 前校验 `/proc/<pid>/cmdline` 必须含 `rootd-priv.sh`，否则拒绝。

**中危：off 标志可被伪造，开机时阻止守护启动**

`wait_base()` 里认 `/sdcard/rootd-out/off`，任何 App 造这个文件，开机窗口期守护直接退出。

**修复**：只认 `$SECURE/off`（私有 700）和 `$MODDIR/off`，`/sdcard` 那份降为镜像。

**低危：service.d 启动器是死代码**

`customize.sh` 往 `/data/adb/service.d/` 投放 `99-rootd.sh`，
但日志显示它从未执行（无 `service.d launcher ran` 记录）。

**修复**：`customize.sh` 不再投放，并删除已有的 `99-rootd.sh`。

**真机攻击实测**

| 测试 | 结果 |
|---|---|
| 往 `/sdcard` 写假 pid（16642，一个 sleep 进程） | ✅ 进程存活，攻击无效 |
| 创建 `/sdcard/rootd-out/off` | ✅ 守护仍返回 `STILL_ALIVE` |
| `service.d/99-rootd.sh` | ✅ 已删除 |
| 启动链路 | ✅ `boot-completed.sh → service.sh → init ctl.start` 正常 |

---

### Bug 2：boot 日志无限增长（已修）

**现象**：`/sdcard/rootd-boot.log` 每次 `service.sh` 启动追加一行，永不清理。

**修复**：写入前先轮转 —— 超过 64KB 就 `tail -n 200` 截断（约 13KB）。真机实测 130000B/2000行 → 13000B/200行。

**待验证**：WebUI 两个按钮（开启/取消）在真机上的实际表现。
